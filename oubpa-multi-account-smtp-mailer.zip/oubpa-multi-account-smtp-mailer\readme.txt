=== OUBPA Multi-Account SMTP Mailer ===
Contributors: bahafed, themestar
Tags: smtp, email, mailer, multi account, google workspace
Requires at least: 5.7
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Send WordPress emails through multiple SMTP accounts with failover, round-robin, test emails and an email log.

== Description ==

OUBPA Multi-Account SMTP Mailer lets you send all WordPress emails (contact forms, WooCommerce, password resets, notifications) through multiple SMTP accounts, including Gmail or Google Workspace SMTP:

* Unlimited Gmail / Google Workspace SMTP accounts
* Gmail preset: smtp.gmail.com : 587 TLS (or 465 SSL)
* Sending strategies: Failover, Round-Robin, Random
* Automatic failover: on quota or auth failure, retries with the next Gmail account
* Force From Name/Email to match the SMTP account (better Gmail deliverability)
* Per-account Reply-To control
* Test Email tool (automatic or per-account)
* Email log with status, account used, recipient and error message
* View the raw text or rendered HTML of any logged email
* Encrypted password storage (OpenSSL AES-256-CBC)
* Debug mode (logs SMTP transcript to the PHP error log)
* Spam-protected contact form shortcode

OUBPA Multi-Account SMTP Mailer is an independent plugin. It is not affiliated with, endorsed by, or sponsored by Google. Gmail and Google Workspace are trademarks of Google LLC, used here only to describe the SMTP service you can connect to.

= Advanced (OUBPA Mailer PRO) =

Multi-provider SMTP (Amazon SES, SendGrid, Mailgun, Postmark, Brevo), smart routing by email type, per-sender rate limits, health checks, delivery analytics, open & click tracking, template builder, attachments, scheduled sending, bounce & suppression handling, REST API & webhooks, multisite and priority support.

== Installation ==

1. Upload the `oubpa-multi-account-smtp-mailer` folder to `/wp-content/plugins/` and activate the plugin.
2. Go to Settings → OUBPA SMTP → Gmail Guide and create a Google App Password.
3. Add your Gmail account(s), save, then send a Test Email.

== Frequently Asked Questions ==

= Do I use my Gmail login password? =

No. Enable Google 2-Step Verification, then generate a 16-character App Password and use that as the SMTP password.

= What are Gmail limits? =

Free Gmail is about 500 emails/day, Google Workspace about 2000/day. Add multiple accounts and use Round-Robin or Failover to spread or continue sending.

= Username and Password not accepted (535)? =

You used the login password instead of an App Password, or 2-Step Verification is off.

= Does it work with WooCommerce and contact forms? =

Yes. Anything that uses wp_mail is routed through OUBPA Multi-Account SMTP Mailer automatically.

== External Services ==

This plugin connects to the SMTP server you configure in the settings to send your site's email. The default preset uses Google Gmail / Google Workspace SMTP (smtp.gmail.com).

The plugin sends the email content your site already generates (recipient, subject, message and headers) and your SMTP credentials to that server only. Nothing is sent to the plugin author.

* Gmail / Google Workspace - https://policies.google.com/terms
* Google Privacy Policy - https://policies.google.com/privacy

== Screenshots ==

1. Gmail Accounts tab with sender identity.
2. Sending & Log settings.
3. Test Email tool.
4. Email Log with the email viewer.

== Changelog ==

= 2.0.1 =
* Renamed the plugin to "OUBPA Multi-Account SMTP Mailer" (new text domain oubpa-multi-account-smtp-mailer).
* Renamed the main plugin file to oubpa-multi-account-smtp-mailer.php.
* Added bahafed to the Contributors list.

= 2.0.0 =
* Renamed the plugin to "SMTP Gmail Multi" (new text domain smtp-gmail-multi).
* Renamed the main plugin file to smtp-gmail-multi.php.
* Documented the external Gmail/Google Workspace SMTP service under External Services.

= 1.1.9 =
* Added an SMTP Gmail Multi PRO tab with an advanced feature presentation and Free vs PRO comparison.
* Security and WordPress coding standards fixes.

= 1.1.5 =
* Log from_email, headers and message columns; back-filled on existing installs.

= 1.0.0 =
* Initial release: multi Gmail SMTP, failover/round-robin/random, test email, email log.

== Upgrade Notice ==

= 2.0.1 =
Plugin renamed to "OUBPA Multi-Account SMTP Mailer". Your accounts, settings and email log are preserved.

= 2.0.0 =
Plugin renamed to "SMTP Gmail Multi". Your accounts, settings and email log are preserved.

= 1.1.9 =
Added an SMTP Gmail Multi PRO tab plus security and coding-standards fixes.
