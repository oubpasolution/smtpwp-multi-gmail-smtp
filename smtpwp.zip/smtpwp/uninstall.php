<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}
global $wpdb;
$table = $wpdb->prefix . 'smtpwp_log';
$wpdb->query( "DROP TABLE IF EXISTS {$table}" );
delete_option( 'smtpwp_accounts' );
delete_option( 'smtpwp_settings' );
delete_option( 'smtpwp_rr_index' );
