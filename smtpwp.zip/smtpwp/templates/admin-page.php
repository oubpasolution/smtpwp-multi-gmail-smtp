<?php if ( ! defined( 'ABSPATH' ) ) exit;
/** @var string $tab */ /** @var array $accounts */ /** @var array $settings */
/** @var array|null $editing */ /** @var string $notice */ /** @var string $msg */
/** @var array|null $default_acc */ /** @var int $active_count */ /** @var int $total_count */
/** @var int $log_count */ /** @var string $last_status */
$store = SMTPWP_Store::instance();
$strategy_labels = array(
  'failover'    => __( 'Failover', 'smtpwp' ),
  'round_robin' => __( 'Round-robin', 'smtpwp' ),
  'random'      => __( 'Random', 'smtpwp' ),
);
?>
<div class="wrap smtpwp-wrap">
  <div class="smtpwp-hero">
    <div class="smtpwp-hero-left">
      <span class="smtpwp-logo" aria-hidden="true"><span class="dashicons dashicons-email-alt"></span></span>
      <div>
        <h1><?php esc_html_e( 'SMTPWP — Multi Gmail SMTP', 'smtpwp' ); ?> <span class="smtpwp-ver">v<?php echo esc_html( SMTPWP_VERSION ); ?></span></h1>
        <p class="smtpwp-subtitle"><?php esc_html_e( 'Send WordPress mail through unlimited Gmail accounts with failover, round-robin and full sender control.', 'smtpwp' ); ?></p>
      </div>
    </div>
    <div class="smtpwp-stats">
      <div class="smtpwp-stat"><span class="smtpwp-stat-num"><?php echo intval( $active_count ); ?>/<?php echo intval( $total_count ); ?></span><span class="smtpwp-stat-lbl"><?php esc_html_e( 'Active accounts', 'smtpwp' ); ?></span></div>
      <div class="smtpwp-stat"><span class="smtpwp-stat-num smtpwp-strategy"><?php echo esc_html( isset( $strategy_labels[ $settings['strategy'] ] ) ? $strategy_labels[ $settings['strategy'] ] : $settings['strategy'] ); ?></span><span class="smtpwp-stat-lbl"><?php esc_html_e( 'Strategy', 'smtpwp' ); ?></span></div>
      <div class="smtpwp-stat"><span class="smtpwp-stat-num"><?php echo intval( $log_count ); ?></span><span class="smtpwp-stat-lbl"><?php esc_html_e( 'Logged emails', 'smtpwp' ); ?></span></div>
      <div class="smtpwp-stat">
        <span class="smtpwp-stat-num smtpwp-status-<?php echo $last_status === 'sent' ? 'ok' : ( $last_status === 'failed' ? 'bad' : 'none' ); ?>"><?php echo $last_status === '' ? esc_html__( '—', 'smtpwp' ) : esc_html( $last_status ); ?></span>
        <span class="smtpwp-stat-lbl"><?php esc_html_e( 'Last send', 'smtpwp' ); ?></span>
      </div>
    </div>
  </div>

  <?php if ( $default_acc ) : ?>
    <div class="smtpwp-senderbar">
      <span class="dashicons dashicons-admin-users"></span>
      <span><strong><?php esc_html_e( 'Default sender:', 'smtpwp' ); ?></strong>
      <code class="smtpwp-sender-code"><?php echo esc_html( $store->sender_string( $default_acc ) ); ?></code></span>
      <span class="smtpwp-sender-meta"><?php echo esc_html( $default_acc['label'] ); ?> · <code><?php echo esc_html( $default_acc['host'] . ':' . $default_acc['port'] . ' ' . strtoupper( $default_acc['encryption'] ) ); ?></code> · <?php esc_html_e( 'Reply-To:', 'smtpwp' ); ?> <code><?php echo esc_html( $store->reply_to_string( $default_acc ) ); ?></code></span>
    </div>
  <?php endif; ?>

  <?php if ( $notice === 'ok' ) : ?>
    <div class="notice notice-success is-dismissible smtpwp-notice"><p><?php echo esc_html( $msg ); ?></p></div>
  <?php elseif ( $notice === 'error' ) : ?>
    <div class="notice notice-error is-dismissible smtpwp-notice"><p><?php echo esc_html( $msg ); ?></p></div>
  <?php endif; ?>

  <h2 class="nav-tab-wrapper smtpwp-tabs">
    <a href="<?php echo esc_url( admin_url( 'options-general.php?page=smtpwp&tab=accounts' ) ); ?>" class="nav-tab <?php echo $tab === 'accounts' ? 'nav-tab-active' : ''; ?>"><span class="dashicons dashicons-admin-users"></span> <?php esc_html_e( 'Gmail Accounts', 'smtpwp' ); ?> <span class="smtpwp-count"><?php echo count( $accounts ); ?></span></a>
    <a href="<?php echo esc_url( admin_url( 'options-general.php?page=smtpwp&tab=settings' ) ); ?>" class="nav-tab <?php echo $tab === 'settings' ? 'nav-tab-active' : ''; ?>"><span class="dashicons dashicons-admin-settings"></span> <?php esc_html_e( 'Sending & Log', 'smtpwp' ); ?></a>
    <a href="<?php echo esc_url( admin_url( 'options-general.php?page=smtpwp&tab=test' ) ); ?>" class="nav-tab <?php echo $tab === 'test' ? 'nav-tab-active' : ''; ?>"><span class="dashicons dashicons-email"></span> <?php esc_html_e( 'Test Email', 'smtpwp' ); ?></a>
    <a href="<?php echo esc_url( admin_url( 'options-general.php?page=smtpwp&tab=log' ) ); ?>" class="nav-tab <?php echo $tab === 'log' ? 'nav-tab-active' : ''; ?>"><span class="dashicons dashicons-list-view"></span> <?php esc_html_e( 'Email Log', 'smtpwp' ); ?> <span class="smtpwp-count"><?php echo intval( $log_count ); ?></span></a>
    <a href="<?php echo esc_url( admin_url( 'options-general.php?page=smtpwp&tab=help' ) ); ?>" class="nav-tab <?php echo $tab === 'help' ? 'nav-tab-active' : ''; ?>"><span class="dashicons dashicons-editor-help"></span> <?php esc_html_e( 'Gmail Guide', 'smtpwp' ); ?></a>
    <a href="<?php echo esc_url( admin_url( 'options-general.php?page=smtpwp&tab=pro' ) ); ?>" class="nav-tab smtpwp-pro-tab <?php echo $tab === 'pro' ? 'nav-tab-active' : ''; ?>"><span class="dashicons dashicons-star-filled"></span> <?php esc_html_e( 'SMTPWP PRO', 'smtpwp' ); ?></a>
  </h2>

  <?php if ( $tab === 'accounts' ) : ?>

    <div class="smtpwp-grid">
      <div class="smtpwp-card smtpwp-list">
        <div class="smtpwp-card-head">
          <h2><span class="dashicons dashicons-admin-users"></span> <?php esc_html_e( 'Sender Accounts', 'smtpwp' ); ?></h2>
          <span class="smtpwp-hint"><?php esc_html_e( 'Each row shows full sender identity: Label, From Name, From Email, Reply-To.', 'smtpwp' ); ?></span>
        </div>
        <?php if ( empty( $accounts ) ) : ?>
          <div class="smtpwp-empty">
            <span class="dashicons dashicons-email-alt"></span>
            <p><strong><?php esc_html_e( 'No Gmail accounts yet.', 'smtpwp' ); ?></strong><br><?php esc_html_e( 'Add your first sender on the right — From Name + From Email is what recipients see.', 'smtpwp' ); ?></p>
          </div>
        <?php else : ?>
          <div class="smtpwp-account-cards">
          <?php foreach ( $accounts as $acc ) :
            $initial = strtoupper( substr( (string) ( $acc['from_name'] !== '' ? $acc['from_name'] : $acc['label'] ), 0, 1 ) );
          ?>
            <div class="smtpwp-acc <?php echo ! empty( $acc['is_active'] ) ? 'is-active' : 'is-off'; ?>" data-id="<?php echo esc_attr( $acc['id'] ); ?>">
              <div class="smtpwp-acc-avatar" aria-hidden="true"><?php echo esc_html( $initial !== '' ? $initial : 'G' ); ?></div>
              <div class="smtpwp-acc-main">
                <div class="smtpwp-acc-top">
                  <strong class="smtpwp-acc-label"><?php echo esc_html( $acc['label'] ); ?></strong>
                  <?php if ( ! empty( $acc['is_default'] ) ) : ?><span class="smtpwp-badge gold"><?php esc_html_e( 'DEFAULT SENDER', 'smtpwp' ); ?></span><?php endif; ?>
                  <?php if ( ! empty( $acc['is_active'] ) ) : ?><span class="smtpwp-badge green"><?php esc_html_e( 'Active', 'smtpwp' ); ?></span><?php else : ?><span class="smtpwp-badge gray"><?php esc_html_e( 'Disabled', 'smtpwp' ); ?></span><?php endif; ?>
                </div>
                <div class="smtpwp-sender-line"><span class="dashicons dashicons-email"></span> <strong><?php esc_html_e( 'From:', 'smtpwp' ); ?></strong> <code><?php echo esc_html( $store->sender_string( $acc ) ); ?></code></div>
                <div class="smtpwp-sender-line muted"><span class="dashicons dashicons-undo"></span> <strong><?php esc_html_e( 'Reply-To:', 'smtpwp' ); ?></strong> <code><?php echo esc_html( $store->reply_to_string( $acc ) ); ?></code></div>
                <div class="smtpwp-sender-line muted"><span class="dashicons dashicons-admin-network"></span> <code><?php echo esc_html( $acc['username'] ); ?></code> · <code><?php echo esc_html( $acc['host'] . ':' . $acc['port'] ); ?></code> · <code><?php echo esc_html( strtoupper( $acc['encryption'] ) ); ?></code><?php echo ! empty( $acc['auth'] ) ? ' · Auth' : ''; ?></div>
                <div class="smtpwp-actions">
                  <a class="button button-small" href="<?php echo esc_url( admin_url( 'options-general.php?page=smtpwp&tab=accounts&edit=' . $acc['id'] ) ); ?>"><span class="dashicons dashicons-edit"></span> <?php esc_html_e( 'Edit', 'smtpwp' ); ?></a>
                  <button class="button button-small smtpwp-toggle"><?php echo ! empty( $acc['is_active'] ) ? esc_html__( 'Disable', 'smtpwp' ) : esc_html__( 'Enable', 'smtpwp' ); ?></button>
                  <?php if ( empty( $acc['is_default'] ) ) : ?>
                    <button class="button button-small smtpwp-default"><?php esc_html_e( 'Set default sender', 'smtpwp' ); ?></button>
                  <?php endif; ?>
                  <button class="button button-small button-link-delete smtpwp-delete"><?php esc_html_e( 'Delete', 'smtpwp' ); ?></button>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          </div>
          <p class="description smtpwp-strategy-note"><span class="dashicons dashicons-randomize"></span> <?php esc_html_e( 'Sending strategy:', 'smtpwp' ); ?> <strong><?php echo esc_html( $settings['strategy'] ); ?></strong> — <?php esc_html_e( 'change it under Sending & Log.', 'smtpwp' ); ?></p>
        <?php endif; ?>
      </div>

      <div class="smtpwp-card smtpwp-form">
        <div class="smtpwp-card-head">
          <h2><span class="dashicons <?php echo $editing ? 'dashicons-edit' : 'dashicons-plus-alt'; ?>"></span> <?php echo $editing ? esc_html__( 'Edit Sender', 'smtpwp' ) : esc_html__( 'Add Gmail Sender', 'smtpwp' ); ?></h2>
        </div>
        <button type="button" class="button smtpwp-preset-btn" id="smtpwp-gmail-preset"><span class="dashicons dashicons-google"></span> <?php esc_html_e( 'Fill Gmail defaults — smtp.gmail.com : 587 TLS', 'smtpwp' ); ?></button>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
          <?php wp_nonce_field( 'smtpwp_save_account' ); ?>
          <input type="hidden" name="action" value="smtpwp_save_account" />
          <input type="hidden" name="id" value="<?php echo $editing ? esc_attr( $editing['id'] ) : ''; ?>" />
          <div class="smtpwp-field">
            <label for="smtpwp-label"><?php esc_html_e( 'Sender Label (internal)', 'smtpwp' ); ?></label>
            <input id="smtpwp-label" name="label" class="regular-text" value="<?php echo $editing ? esc_attr( $editing['label'] ) : ''; ?>" placeholder="e.g. Support Gmail" required />
            <p class="description"><?php esc_html_e( 'Shown in this list + email log. Recipients do NOT see it.', 'smtpwp' ); ?></p>
          </div>
          <div class="smtpwp-field-row">
            <div class="smtpwp-field">
              <label for="smtpwp-from-name"><?php esc_html_e( 'From Name (recipients see this)', 'smtpwp' ); ?></label>
              <input id="smtpwp-from-name" name="from_name" class="regular-text" value="<?php echo $editing ? esc_attr( $editing['from_name'] ) : ''; ?>" placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" />
            </div>
            <div class="smtpwp-field">
              <label for="smtpwp-from-email"><?php esc_html_e( 'From Email (recipients see this)', 'smtpwp' ); ?></label>
              <input id="smtpwp-from-email" name="from_email" type="email" class="regular-text" value="<?php echo $editing ? esc_attr( $editing['from_email'] ) : ''; ?>" placeholder="you@gmail.com" required />
            </div>
          </div>
          <div class="smtpwp-sender-preview" id="smtpwp-sender-preview" hidden>
            <span class="dashicons dashicons-visibility"></span> <span id="smtpwp-sender-preview-text"></span>
          </div>
          <div class="smtpwp-field-row">
            <div class="smtpwp-field">
              <label for="smtpwp-reply-name"><?php esc_html_e( 'Reply-To Name (optional)', 'smtpwp' ); ?></label>
              <input id="smtpwp-reply-name" name="reply_to_name" class="regular-text" value="<?php echo $editing ? esc_attr( isset( $editing['reply_to_name'] ) ? $editing['reply_to_name'] : '' ) : ''; ?>" placeholder="<?php esc_attr_e( 'Same as From', 'smtpwp' ); ?>" />
            </div>
            <div class="smtpwp-field">
              <label for="smtpwp-reply-email"><?php esc_html_e( 'Reply-To Email (optional)', 'smtpwp' ); ?></label>
              <input id="smtpwp-reply-email" name="reply_to_email" type="email" class="regular-text" value="<?php echo $editing ? esc_attr( isset( $editing['reply_to_email'] ) ? $editing['reply_to_email'] : '' ) : ''; ?>" placeholder="<?php esc_attr_e( 'Same as From', 'smtpwp' ); ?>" />
            </div>
          </div>
          <div class="smtpwp-field-row">
            <div class="smtpwp-field">
              <label for="smtpwp-host"><?php esc_html_e( 'SMTP Host', 'smtpwp' ); ?></label>
              <input id="smtpwp-host" name="host" class="regular-text" value="<?php echo $editing ? esc_attr( $editing['host'] ) : 'smtp.gmail.com'; ?>" required />
            </div>
            <div class="smtpwp-field">
              <label for="smtpwp-port"><?php esc_html_e( 'Port', 'smtpwp' ); ?></label>
              <input id="smtpwp-port" name="port" type="number" class="small-text" value="<?php echo $editing ? esc_attr( $editing['port'] ) : '587'; ?>" required />
              <span class="description">587 TLS · 465 SSL</span>
            </div>
            <div class="smtpwp-field">
              <label for="smtpwp-enc"><?php esc_html_e( 'Encryption', 'smtpwp' ); ?></label>
              <select id="smtpwp-enc" name="encryption">
                <option value="tls" <?php echo ( $editing && $editing['encryption'] === 'tls' ) || ! $editing ? 'selected' : ''; ?>>TLS</option>
                <option value="ssl" <?php echo ( $editing && $editing['encryption'] === 'ssl' ) ? 'selected' : ''; ?>>SSL</option>
                <option value="none" <?php echo ( $editing && $editing['encryption'] === 'none' ) ? 'selected' : ''; ?>><?php esc_html_e( 'None', 'smtpwp' ); ?></option>
              </select>
            </div>
          </div>
          <div class="smtpwp-field">
            <label class="smtpwp-check"><input type="checkbox" name="auth" value="1" <?php echo ! $editing || ! empty( $editing['auth'] ) ? 'checked' : ''; ?> /> <?php esc_html_e( 'Use SMTP authentication (always ON for Gmail)', 'smtpwp' ); ?></label>
          </div>
          <div class="smtpwp-field-row">
            <div class="smtpwp-field">
              <label for="smtpwp-user"><?php esc_html_e( 'Gmail / Username', 'smtpwp' ); ?></label>
              <input id="smtpwp-user" name="username" class="regular-text" value="<?php echo $editing ? esc_attr( $editing['username'] ) : ''; ?>" placeholder="you@gmail.com" />
            </div>
            <div class="smtpwp-field">
              <label for="smtpwp-pass"><?php esc_html_e( 'App Password', 'smtpwp' ); ?></label>
              <div class="smtpwp-passwrap"><input id="smtpwp-pass" name="password" type="password" class="regular-text" value="" placeholder="<?php echo $editing ? esc_attr__( 'Leave empty to keep saved password', 'smtpwp' ) : 'xxxx xxxx xxxx xxxx'; ?>" <?php echo $editing ? '' : 'required'; ?> autocomplete="new-password" /><button type="button" class="button" id="smtpwp-pass-toggle" aria-label="Show password"><span class="dashicons dashicons-visibility"></span></button></div>
              <p class="description"><?php esc_html_e( '16-char Google App Password — NOT your login password. See Gmail Guide.', 'smtpwp' ); ?></p>
            </div>
          </div>
          <div class="smtpwp-field smtpwp-checks">
            <label class="smtpwp-check"><input type="checkbox" name="is_active" value="1" <?php echo ! $editing || ! empty( $editing['is_active'] ) ? 'checked' : ''; ?> /> <?php esc_html_e( 'Active — include in sending rotation', 'smtpwp' ); ?></label>
            <label class="smtpwp-check"><input type="checkbox" name="is_default" value="1" <?php echo ( $editing && ! empty( $editing['is_default'] ) ) ? 'checked' : ''; ?> /> <?php esc_html_e( 'Set as default sender', 'smtpwp' ); ?></label>
          </div>
          <div class="smtpwp-form-actions">
            <?php submit_button( $editing ? __( 'Update Sender', 'smtpwp' ) : __( 'Add Sender', 'smtpwp' ), 'primary', 'submit', false ); ?>
            <?php if ( $editing ) : ?>
              <a class="button" href="<?php echo esc_url( admin_url( 'options-general.php?page=smtpwp&tab=accounts' ) ); ?>"><?php esc_html_e( 'Cancel', 'smtpwp' ); ?></a>
            <?php endif; ?>
          </div>
        </form>
      </div>
    </div>

  <?php elseif ( $tab === 'settings' ) : ?>
    <div class="smtpwp-card smtpwp-narrow">
      <div class="smtpwp-card-head"><h2><span class="dashicons dashicons-admin-settings"></span> <?php esc_html_e( 'Sending & Log Settings', 'smtpwp' ); ?></h2></div>
      <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <?php wp_nonce_field( 'smtpwp_save_settings' ); ?>
        <input type="hidden" name="action" value="smtpwp_save_settings" />
        <div class="smtpwp-strat-grid">
          <label class="smtpwp-strat <?php echo $settings['strategy'] === 'failover' ? 'is-sel' : ''; ?>"><input type="radio" name="strategy" value="failover" <?php checked( $settings['strategy'], 'failover' ); ?> /><strong><?php esc_html_e( 'Failover', 'smtpwp' ); ?></strong><span><?php esc_html_e( 'Default sender first, auto-switch to next Gmail on failure.', 'smtpwp' ); ?></span></label>
          <label class="smtpwp-strat <?php echo $settings['strategy'] === 'round_robin' ? 'is-sel' : ''; ?>"><input type="radio" name="strategy" value="round_robin" <?php checked( $settings['strategy'], 'round_robin' ); ?> /><strong><?php esc_html_e( 'Round-robin', 'smtpwp' ); ?></strong><span><?php esc_html_e( 'Rotate senders per email — spreads Gmail quota.', 'smtpwp' ); ?></span></label>
          <label class="smtpwp-strat <?php echo $settings['strategy'] === 'random' ? 'is-sel' : ''; ?>"><input type="radio" name="strategy" value="random" <?php checked( $settings['strategy'], 'random' ); ?> /><strong><?php esc_html_e( 'Random', 'smtpwp' ); ?></strong><span><?php esc_html_e( 'Random sender per email.', 'smtpwp' ); ?></span></label>
        </div>
        <div class="smtpwp-field">
          <label for="smtpwp-default"><?php esc_html_e( 'Default sender account', 'smtpwp' ); ?></label>
          <select id="smtpwp-default" name="default_account">
            <option value=""><?php esc_html_e( '— Automatic (first active) —', 'smtpwp' ); ?></option>
            <?php foreach ( $accounts as $acc ) : ?>
              <option value="<?php echo esc_attr( $acc['id'] ); ?>" <?php selected( $settings['default_account'], $acc['id'] ); ?>><?php echo esc_html( $acc['label'] . ' — ' . $store->sender_string( $acc ) ); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="smtpwp-field"><label class="smtpwp-check"><input type="checkbox" name="force_from" value="1" <?php checked( ! empty( $settings['force_from'] ) ); ?> /> <?php esc_html_e( 'Force From Name/Email to match the SMTP sender (recommended — fixes Gmail "via" / spoof blocks).', 'smtpwp' ); ?></label></div>
        <div class="smtpwp-field"><label class="smtpwp-check"><input type="checkbox" name="log_enabled" value="1" <?php checked( ! empty( $settings['log_enabled'] ) ); ?> /> <?php esc_html_e( 'Enable email log (sender, recipient, subject, status, error)', 'smtpwp' ); ?></label></div>
        <div class="smtpwp-field-row">
          <div class="smtpwp-field"><label><?php esc_html_e( 'Keep logs (days, 0 = forever)', 'smtpwp' ); ?></label><input type="number" name="log_retention" class="small-text" value="<?php echo esc_attr( $settings['log_retention'] ); ?>" min="0" /></div>
          <div class="smtpwp-field"><label class="smtpwp-check"><input type="checkbox" name="clear_log" value="1" /> <?php esc_html_e( 'Clear entire log now', 'smtpwp' ); ?></label></div>
        </div>
        <div class="smtpwp-field"><label class="smtpwp-check"><input type="checkbox" name="debug" value="1" <?php checked( ! empty( $settings['debug'] ) ); ?> /> <?php esc_html_e( 'Debug mode — write SMTP transcript to PHP error log', 'smtpwp' ); ?></label></div>
        <?php submit_button( __( 'Save Settings', 'smtpwp' ) ); ?>
      </form>
    </div>

  <?php elseif ( $tab === 'test' ) : ?>
    <div class="smtpwp-grid smtpwp-test-grid">
      <div class="smtpwp-card">
        <div class="smtpwp-card-head"><h2><span class="dashicons dashicons-email"></span> <?php esc_html_e( 'Send Test Email', 'smtpwp' ); ?></h2></div>
        <div class="smtpwp-field">
          <label for="smtpwp-test-to"><strong><?php esc_html_e( 'Send to', 'smtpwp' ); ?></strong></label>
          <input id="smtpwp-test-to" type="email" class="regular-text" value="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" placeholder="recipient@example.com" />
        </div>
        <div class="smtpwp-field">
          <label for="smtpwp-test-acc"><strong><?php esc_html_e( 'Sender account', 'smtpwp' ); ?></strong></label>
          <select id="smtpwp-test-acc">
            <option value="" data-sender="<?php echo esc_attr( $default_acc ? $store->sender_string( $default_acc ) : '' ); ?>" data-reply="<?php echo esc_attr( $default_acc ? $store->reply_to_string( $default_acc ) : '' ); ?>"><?php esc_html_e( 'Automatic (use sending strategy)', 'smtpwp' ); ?></option>
            <?php foreach ( $accounts as $acc ) : ?>
              <option value="<?php echo esc_attr( $acc['id'] ); ?>" data-sender="<?php echo esc_attr( $store->sender_string( $acc ) ); ?>" data-reply="<?php echo esc_attr( $store->reply_to_string( $acc ) ); ?>"><?php echo esc_html( $acc['label'] . ' — ' . $store->sender_string( $acc ) ); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="smtpwp-field">
          <label for="smtpwp-test-subject"><strong><?php esc_html_e( 'Subject', 'smtpwp' ); ?></strong></label>
          <input id="smtpwp-test-subject" type="text" class="large-text" value="<?php esc_attr_e( 'SMTPWP Test Email', 'smtpwp' ); ?>" />
        </div>
        <div class="smtpwp-field">
          <label for="smtpwp-test-msg"><strong><?php esc_html_e( 'Message', 'smtpwp' ); ?></strong></label>
          <textarea id="smtpwp-test-msg" rows="5" class="large-text"><?php esc_html_e( 'If you received this, your Gmail SMTP sender is working.', 'smtpwp' ); ?>&#10;&#10;Site: <?php echo esc_html( get_bloginfo( 'name' ) . ' (' . home_url() . ')' ); ?>&#10;Time: <?php echo esc_html( current_time( 'mysql' ) ); ?></textarea>
        </div>
        <p><button class="button button-primary button-large" id="smtpwp-test-send"><span class="dashicons dashicons-email"></span> <?php esc_html_e( 'Send Test Email', 'smtpwp' ); ?></button>
        <span id="smtpwp-test-result" role="status"></span></p>
        <?php if ( empty( $accounts ) ) : ?>
          <div class="notice notice-warning inline"><p><?php esc_html_e( 'Add at least one Gmail sender first.', 'smtpwp' ); ?></p></div>
        <?php endif; ?>
      </div>
      <div class="smtpwp-card smtpwp-senderinfo">
        <div class="smtpwp-card-head"><h2><span class="dashicons dashicons-visibility"></span> <?php esc_html_e( 'Email identity preview', 'smtpwp' ); ?></h2></div>
        <div class="smtpwp-mailprev">
          <div class="smtpwp-mailprev-row"><span><?php esc_html_e( 'From', 'smtpwp' ); ?></span><code id="smtpwp-prev-from">—</code></div>
          <div class="smtpwp-mailprev-row"><span><?php esc_html_e( 'Reply-To', 'smtpwp' ); ?></span><code id="smtpwp-prev-reply">—</code></div>
          <div class="smtpwp-mailprev-row"><span><?php esc_html_e( 'To', 'smtpwp' ); ?></span><code id="smtpwp-prev-to">—</code></div>
          <div class="smtpwp-mailprev-row"><span><?php esc_html_e( 'Subject', 'smtpwp' ); ?></span><code id="smtpwp-prev-subject">—</code></div>
        </div>
        <h3><?php esc_html_e( 'What recipients see', 'smtpwp' ); ?></h3>
        <ul class="ul-disc">
          <li><?php esc_html_e( 'Label = internal only (never sent).', 'smtpwp' ); ?></li>
          <li><?php esc_html_e( 'From Name + From Email = the sender header every inbox displays.', 'smtpwp' ); ?></li>
          <li><?php esc_html_e( 'Reply-To = where replies go. Empty = replies go to From.', 'smtpwp' ); ?></li>
          <li><?php esc_html_e( 'Keep From Email = the Gmail account itself, or Gmail may rewrite it.', 'smtpwp' ); ?></li>
        </ul>
      </div>
    </div>

  <?php elseif ( $tab === 'log' ) : ?>
    <div class="smtpwp-card" id="smtpwp-log-wrap" data-page="1" data-per="20">
      <div class="smtpwp-card-head smtpwp-log-head">
        <h2><span class="dashicons dashicons-list-view"></span> <?php esc_html_e( 'Email Log', 'smtpwp' ); ?> <span class="smtpwp-count" id="smtpwp-log-count"><?php echo intval( $log_count ); ?></span></h2>
        <span class="smtpwp-log-tools">
          <span class="description"><?php esc_html_e( '20 per page · AJAX pagination · every wp_mail email is logged here', 'smtpwp' ); ?></span>
          <a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=smtpwp_export_log' ), 'smtpwp_export_log' ) ); ?>"><span class="dashicons dashicons-download"></span> <?php esc_html_e( 'Export CSV', 'smtpwp' ); ?></a>
        </span>
      </div>
      <?php
      $per = 20;
      $pages = max( 1, (int) ceil( $log_count / $per ) );
      $logs = SMTPWP_Logger::instance()->get_logs( $per, 0 );
      ?>
      <?php if ( empty( $logs ) ) : ?>
        <div class="smtpwp-empty"><span class="dashicons dashicons-list-view"></span><p><strong><?php esc_html_e( 'No emails logged yet.', 'smtpwp' ); ?></strong><br><?php esc_html_e( 'Send a test email — sender, recipient, subject and status will appear here.', 'smtpwp' ); ?></p></div>
      <?php else : ?>
        <div class="smtpwp-tablewrap"><table class="widefat striped smtpwp-table smtpwp-logtable">
          <thead><tr><th>ID</th><th><?php esc_html_e( 'Date', 'smtpwp' ); ?></th><th><?php esc_html_e( 'Sender (From)', 'smtpwp' ); ?></th><th><?php esc_html_e( 'To', 'smtpwp' ); ?></th><th><?php esc_html_e( 'Subject', 'smtpwp' ); ?></th><th><?php esc_html_e( 'Status', 'smtpwp' ); ?></th><th><?php esc_html_e( 'Error / Info', 'smtpwp' ); ?></th><th><?php esc_html_e( 'View', 'smtpwp' ); ?></th></tr></thead>
          <tbody id="smtpwp-log-body">
          <?php foreach ( (array) $logs as $row ) : ?>
            <tr>
              <td><?php echo intval( $row['id'] ); ?></td>
              <td class="smtpwp-nowrap"><?php echo esc_html( $row['created_at'] ); ?></td>
              <td><span class="smtpwp-sender-chip"><?php echo esc_html( $row['account_label'] !== '' ? $row['account_label'] : $row['account_id'] ); ?></span></td>
              <td><?php echo esc_html( $row['to_email'] ); ?></td>
              <td><?php echo esc_html( $row['subject'] ); ?></td>
              <td><?php echo $row['status'] === 'sent' ? '<span class="smtpwp-badge green">● sent</span>' : '<span class="smtpwp-badge red">● failed</span>'; ?></td>
              <td class="smtpwp-err"><?php echo esc_html( mb_substr( (string) $row['error_message'], 0, 300 ) ); ?></td>
              <td><button type="button" class="button button-small smtpwp-view" data-id="<?php echo intval( $row['id'] ); ?>" title="<?php esc_attr_e( 'View email content', 'smtpwp' ); ?>"><span class="dashicons dashicons-visibility"></span></button></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table></div>
        <div class="smtpwp-pager" id="smtpwp-log-pager">
          <button class="button" id="smtpwp-log-prev" disabled>← <?php esc_html_e( 'Newer', 'smtpwp' ); ?></button>
          <span class="description" id="smtpwp-log-info"><?php printf( esc_html__( 'Page %d of %d · %d emails · 20 per page', 'smtpwp' ), 1, $pages, intval( $log_count ) ); ?></span>
          <button class="button" id="smtpwp-log-next" <?php echo $pages <= 1 ? 'disabled' : ''; ?>><?php esc_html_e( 'Older', 'smtpwp' ); ?> →</button>
        </div>
        <div class="smtpwp-pagenums" id="smtpwp-log-pages"></div>
        <span id="smtpwp-log-loading" hidden><?php esc_html_e( 'Loading…', 'smtpwp' ); ?></span>
      <?php endif; ?>
    </div>

    <div class="smtpwp-modal" id="smtpwp-view-modal" hidden>
      <div class="smtpwp-modal-box" role="dialog" aria-modal="true" aria-labelledby="smtpwp-view-title">
        <div class="smtpwp-modal-head">
          <h2 id="smtpwp-view-title"><span class="dashicons dashicons-visibility"></span> <?php esc_html_e( 'Email content', 'smtpwp' ); ?></h2>
          <button type="button" class="button smtpwp-modal-close" id="smtpwp-view-close"><span class="dashicons dashicons-no"></span> <?php esc_html_e( 'Close', 'smtpwp' ); ?></button>
        </div>
        <div class="smtpwp-mailprev" id="smtpwp-view-meta">
          <div class="smtpwp-mailprev-row"><span><?php esc_html_e( 'Date', 'smtpwp' ); ?></span><code id="smtpwp-v-date">—</code></div>
          <div class="smtpwp-mailprev-row"><span><?php esc_html_e( 'From', 'smtpwp' ); ?></span><code id="smtpwp-v-from">—</code></div>
          <div class="smtpwp-mailprev-row"><span><?php esc_html_e( 'To', 'smtpwp' ); ?></span><code id="smtpwp-v-to">—</code></div>
          <div class="smtpwp-mailprev-row"><span><?php esc_html_e( 'Subject', 'smtpwp' ); ?></span><code id="smtpwp-v-subject">—</code></div>
          <div class="smtpwp-mailprev-row"><span><?php esc_html_e( 'Status', 'smtpwp' ); ?></span><code id="smtpwp-v-status">—</code></div>
        </div>
        <p id="smtpwp-v-error-wrap" hidden><strong><?php esc_html_e( 'Error / Info:', 'smtpwp' ); ?></strong> <span id="smtpwp-v-error"></span></p>
        <div class="smtpwp-view-tabs">
          <button type="button" class="button button-small smtpwp-view-tab is-on" data-mode="text"><?php esc_html_e( 'Text', 'smtpwp' ); ?></button>
          <button type="button" class="button button-small smtpwp-view-tab" data-mode="html"><?php esc_html_e( 'Rendered HTML', 'smtpwp' ); ?></button>
        </div>
        <pre class="smtpwp-view-body" id="smtpwp-v-body"></pre>
        <iframe class="smtpwp-view-frame" id="smtpwp-v-frame" sandbox="" hidden></iframe>
      </div>
    </div>

  <?php elseif ( $tab === 'help' ) : ?>
    <div class="smtpwp-grid smtpwp-help-grid">
      <div class="smtpwp-card">
        <div class="smtpwp-card-head"><h2><span class="dashicons dashicons-editor-help"></span> <?php esc_html_e( 'Gmail App Password — 4 steps', 'smtpwp' ); ?></h2></div>
        <ol class="smtpwp-steps">
          <li><strong><?php esc_html_e( '2-Step Verification ON', 'smtpwp' ); ?></strong><span><?php esc_html_e( 'Google Account → Security → 2-Step Verification → Turn on.', 'smtpwp' ); ?></span></li>
          <li><strong><?php esc_html_e( 'Create App Password', 'smtpwp' ); ?></strong><span><?php esc_html_e( 'Security → 2-Step Verification → App passwords → "WordPress" → Generate. Copy the 16-char code.', 'smtpwp' ); ?></span></li>
          <li><strong><?php esc_html_e( 'Add sender in SMTPWP', 'smtpwp' ); ?></strong><span><?php esc_html_e( 'Fill Gmail defaults, Label = e.g. "Support", From Name = your brand, From Email = the Gmail, Username = the Gmail, Password = App Password.', 'smtpwp' ); ?></span></li>
          <li><strong><?php esc_html_e( 'Test + scale', 'smtpwp' ); ?></strong><span><?php esc_html_e( 'Test Email tab → check Log. Free Gmail ≈ 500/day, Workspace ≈ 2000/day — add more senders + round-robin.', 'smtpwp' ); ?></span></li>
        </ol>
      </div>
      <div class="smtpwp-card">
        <div class="smtpwp-card-head"><h2><span class="dashicons dashicons-warning"></span> <?php esc_html_e( 'Common Gmail errors', 'smtpwp' ); ?></h2></div>
        <ul class="smtpwp-errlist">
          <li><code>535-5.7.8 not accepted</code><span><?php esc_html_e( 'Wrong App Password, 2-Step off, or login password used.', 'smtpwp' ); ?></span></li>
          <li><code>534-5.7.9 password required</code><span><?php esc_html_e( 'Generate an App Password.', 'smtpwp' ); ?></span></li>
          <li><code>550-5.4.5 quota exceeded</code><span><?php esc_html_e( 'Daily limit hit — failover auto-switches to next sender.', 'smtpwp' ); ?></span></li>
          <li><code>Could not connect</code><span><?php esc_html_e( 'Host blocks ports 587/465 — ask host to open outbound SMTP.', 'smtpwp' ); ?></span></li>
        </ul>
        <h3><?php esc_html_e( 'Sender fields explained', 'smtpwp' ); ?></h3>
        <ul class="ul-disc">
          <li><strong><?php esc_html_e( 'Label', 'smtpwp' ); ?></strong> — <?php esc_html_e( 'internal nickname only.', 'smtpwp' ); ?></li>
          <li><strong><?php esc_html_e( 'From Name / From Email', 'smtpwp' ); ?></strong> — <?php esc_html_e( 'what every inbox displays as the sender.', 'smtpwp' ); ?></li>
          <li><strong><?php esc_html_e( 'Reply-To', 'smtpwp' ); ?></strong> — <?php esc_html_e( 'where replies go. Leave empty to reply to From.', 'smtpwp' ); ?></li>
        </ul>
      </div>
    </div>
  <?php elseif ( $tab === 'pro' ) : ?>
    <div class="smtpwp-card smtpwp-pro-hero">
      <div class="smtpwp-pro-hero-main">
        <span class="smtpwp-pro-logo" aria-hidden="true"><span class="dashicons dashicons-star-filled"></span></span>
        <div>
          <h2><?php esc_html_e( 'SMTPWP PRO', 'smtpwp' ); ?> <span class="smtpwp-badge gold"><?php esc_html_e( 'ADVANCED', 'smtpwp' ); ?></span></h2>
          <p class="smtpwp-hint"><?php esc_html_e( 'Everything in Free, plus multi-provider routing, delivery analytics, tracking and priority support for high-volume sites.', 'smtpwp' ); ?></p>
        </div>
      </div>
      <a class="button button-primary button-hero" href="https://oubpa.com/shop" target="_blank" rel="noopener"><span class="dashicons dashicons-cart"></span> <?php esc_html_e( 'Upgrade to PRO', 'smtpwp' ); ?></a>
    </div>

    <div class="smtpwp-card smtpwp-pro-features">
      <div class="smtpwp-card-head">
        <h2><span class="dashicons dashicons-star-filled"></span> <?php esc_html_e( 'What you unlock in PRO', 'smtpwp' ); ?></h2>
        <span class="smtpwp-hint"><?php esc_html_e( 'Twelve upgrades designed for high-volume, multi-site sending.', 'smtpwp' ); ?></span>
      </div>
      <div class="smtpwp-pro-grid">
      <?php
      $smtpwp_pro_features = array(
        array( 'cloud',          __( 'Multi-provider SMTP', 'smtpwp' ), __( 'Add Google Workspace, Outlook/Office 365, Amazon SES, SendGrid, Mailgun, Postmark and Brevo — not just Gmail.', 'smtpwp' ) ),
        array( 'randomize',      __( 'Smart routing rules', 'smtpwp' ), __( 'Route emails by type — WooCommerce, password resets, contact forms — each through its own sender and provider.', 'smtpwp' ) ),
        array( 'performance',    __( 'Rate limits & throttling', 'smtpwp' ), __( 'Per-sender daily/hourly caps with automatic pause and resume to protect your Gmail reputation.', 'smtpwp' ) ),
        array( 'heart',          __( 'Health checks & failover', 'smtpwp' ), __( 'Background connection tests, automatic sender removal on failure and instant recovery.', 'smtpwp' ) ),
        array( 'chart-bar',      __( 'Delivery analytics', 'smtpwp' ), __( 'Dashboard with sent, delivered, failed and bounced rates per sender, per provider and per day.', 'smtpwp' ) ),
        array( 'visibility',     __( 'Open & click tracking', 'smtpwp' ), __( 'Track opens and link clicks with privacy-friendly reporting and per-campaign breakdowns.', 'smtpwp' ) ),
        array( 'email-alt',      __( 'Email templates', 'smtpwp' ), __( 'Drag-and-drop template builder with live preview for notifications, receipts and campaigns.', 'smtpwp' ) ),
        array( 'media-document', __( 'Attachments support', 'smtpwp' ), __( 'Attach PDFs, invoices and images to any WordPress email safely through your SMTP senders.', 'smtpwp' ) ),
        array( 'clock',          __( 'Scheduled sending', 'smtpwp' ), __( 'Queue emails and send them at the best time with automatic retries on temporary failures.', 'smtpwp' ) ),
        array( 'shield-alt',     __( 'Bounce & suppression', 'smtpwp' ), __( 'Automatic bounce handling and a suppression list to keep sending to valid addresses only.', 'smtpwp' ) ),
        array( 'admin-network',  __( 'REST API & webhooks', 'smtpwp' ), __( 'Send mail programmatically and push delivery events to Zapier, Make or your own endpoint.', 'smtpwp' ) ),
        array( 'sos',            __( 'Priority support', 'smtpwp' ), __( 'Fast-track help, one-click updates and expert migration from your current SMTP setup.', 'smtpwp' ) ),
      );
      foreach ( $smtpwp_pro_features as $i => $f ) :
      ?>
        <div class="smtpwp-pro-feat">
          <span class="smtpwp-pro-num" aria-hidden="true"><?php echo esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
          <div class="smtpwp-pro-feat-text">
            <strong><span class="dashicons dashicons-<?php echo esc_attr( $f[0] ); ?>"></span> <?php echo esc_html( $f[1] ); ?></strong>
            <span><?php echo esc_html( $f[2] ); ?></span>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
    </div>

    <div class="smtpwp-grid smtpwp-help-grid">
      <div class="smtpwp-card">
        <div class="smtpwp-card-head"><h2><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Free vs PRO', 'smtpwp' ); ?></h2></div>
        <div class="smtpwp-tablewrap">
          <table class="widefat striped smtpwp-table">
            <thead><tr><th><?php esc_html_e( 'Feature', 'smtpwp' ); ?></th><th><?php esc_html_e( 'Free', 'smtpwp' ); ?></th><th><?php esc_html_e( 'PRO', 'smtpwp' ); ?></th></tr></thead>
            <tbody>
              <tr><td><?php esc_html_e( 'Gmail / Google Workspace SMTP', 'smtpwp' ); ?></td><td><span class="smtpwp-badge green">✓</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Unlimited Gmail sender accounts', 'smtpwp' ); ?></td><td><span class="smtpwp-badge green">✓</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Failover, Round-robin, Random', 'smtpwp' ); ?></td><td><span class="smtpwp-badge green">✓</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Email log + test email', 'smtpwp' ); ?></td><td><span class="smtpwp-badge green">✓</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Force From Name/Email + Reply-To control', 'smtpwp' ); ?></td><td><span class="smtpwp-badge green">✓</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Encrypted password storage (AES-256)', 'smtpwp' ); ?></td><td><span class="smtpwp-badge green">✓</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Debug mode (SMTP transcript)', 'smtpwp' ); ?></td><td><span class="smtpwp-badge green">✓</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Multi-provider SMTP (SES, SendGrid, Mailgun…)', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Smart routing rules by email type', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Per-sender rate limits &amp; throttling', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Health checks &amp; auto-failover', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Delivery analytics dashboard', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Open &amp; click tracking', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Bounce &amp; complaint handling', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Suppression / blocklist', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Email templates builder + live preview', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Attachments support (PDF, images)', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Scheduled / delayed sending', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Automatic retry queue', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Multiple From domains', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'REST API &amp; webhooks', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Multisite support', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Import / export settings', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Automatic updates', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
              <tr><td><?php esc_html_e( 'Priority support', 'smtpwp' ); ?></td><td><span class="smtpwp-badge gray">—</span></td><td><span class="smtpwp-badge green">✓</span></td></tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="smtpwp-card smtpwp-pro-cta">
        <div class="smtpwp-card-head"><h2><span class="dashicons dashicons-star-filled"></span> <?php esc_html_e( 'Get SMTPWP PRO', 'smtpwp' ); ?></h2></div>
        <ul class="ul-disc">
          <li><?php esc_html_e( 'Unlock every advanced feature listed here.', 'smtpwp' ); ?></li>
          <li><?php esc_html_e( 'Unlimited senders, providers and websites.', 'smtpwp' ); ?></li>
          <li><?php esc_html_e( '1 year of updates + priority support.', 'smtpwp' ); ?></li>
        </ul>
        <p class="smtpwp-hint"><?php esc_html_e( 'Looking for something custom? We build tailored SMTP setups.', 'smtpwp' ); ?></p>
        <a class="button button-primary button-large" href="https://oubpa.com/shop" target="_blank" rel="noopener"><span class="dashicons dashicons-cart"></span> <?php esc_html_e( 'Buy SMTPWP PRO', 'smtpwp' ); ?></a>
        <a class="button button-large" href="https://oubpa.com/contact" target="_blank" rel="noopener"><span class="dashicons dashicons-email"></span> <?php esc_html_e( 'Contact us', 'smtpwp' ); ?></a>
      </div>
    </div>
  <?php endif; ?>
</div>
