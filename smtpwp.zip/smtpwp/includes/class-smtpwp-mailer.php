<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SMTPWP_Mailer {

    private static $instance = null;

    /** @var array Last wp_mail args for failover retry */
    private $last_mail = null;
    /** @var array Ordered account IDs tried in current chain */
    private $try_queue = array();
    private $retrying = false;
    private $current_account_id = '';
    /** @var int Increments per PHPMailer send (coverage tracking) */
    private $send_seq = 0;
    /** @var int Seq of the send currently being configured/sent */
    private $current_seq = 0;
    /** @var array Seqs already logged (prevents double-logging) */
    private $logged_seqs = array();
    /** @var array Seqs seen via PHPMailer callback, awaiting wp_mail hooks */
    private $cb_pending = array();
    /** @var bool A pre_wp_mail short-circuit was logged (skip later hooks for it) */
    private $pre_handled = false;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        add_action( 'phpmailer_init', array( $this, 'configure_phpmailer' ), 9999 );
        add_filter( 'wp_mail', array( $this, 'capture_mail' ), 9999 );
        // Runs last: if another plugin short-circuits sending, $pre is non-null.
        add_filter( 'pre_wp_mail', array( $this, 'capture_pre' ), PHP_INT_MAX, 2 );
        add_action( 'wp_mail_succeeded', array( $this, 'on_succeeded' ), 10, 1 );
        add_action( 'wp_mail_failed', array( $this, 'on_failed' ), 10, 1 );
        // Safety net: flush any send seen by PHPMailer but never reported via wp_mail hooks.
        add_action( 'shutdown', array( $this, 'flush_pending' ), 9999 );
        // Force From to match the SMTP account (improves Gmail deliverability).
        add_filter( 'wp_mail_from', array( $this, 'filter_from' ), 9999 );
        add_filter( 'wp_mail_from_name', array( $this, 'filter_from_name' ), 9999 );
    }

    public function capture_mail( $args ) {
        $this->last_mail = $args;
        return $args;
    }

    /**
     * Observe short-circuited sends. Another plugin returning non-null here
     * bypasses SMTP AND the wp_mail_succeeded/failed hooks, so without this
     * observer such emails would never appear in the log.
     */
    public function capture_pre( $pre, $atts ) {
        if ( null === $pre ) {
            return $pre; // Normal path: core continues to PHPMailer.
        }
        $to      = isset( $atts['to'] ) ? $atts['to'] : '';
        $subject = isset( $atts['subject'] ) ? $atts['subject'] : '';
        $message = isset( $atts['message'] ) ? $atts['message'] : '';
        $headers = isset( $atts['headers'] ) ? $atts['headers'] : '';
        $def     = SMTPWP_Store::instance()->get_default_account();
        SMTPWP_Logger::instance()->log(
            $to,
            $subject,
            '',
            __( 'Other plugin (pre_wp_mail)', 'smtpwp' ),
            ! empty( $pre ) ? 'sent' : 'failed',
            ! empty( $pre )
                ? __( 'Sent by another plugin via pre_wp_mail (bypassed SMTPWP SMTP).', 'smtpwp' )
                : __( 'Blocked by another plugin via pre_wp_mail (bypassed SMTPWP SMTP).', 'smtpwp' ),
            $message,
            $headers,
            $def && ! empty( $def['from_email'] ) ? $def['from_email'] : ''
        );
        $this->pre_handled = true;
        return $pre;
    }

    public function get_current_account_id() {
        return $this->current_account_id;
    }

    public function filter_from( $from ) {
        $settings = SMTPWP_Store::instance()->get_settings();
        if ( empty( $settings['force_from'] ) ) {
            return $from;
        }
        $acc = $this->resolve_current_account();
        if ( $acc && ! empty( $acc['from_email'] ) && is_email( $acc['from_email'] ) ) {
            return $acc['from_email'];
        }
        return $from;
    }

    public function filter_from_name( $name ) {
        $settings = SMTPWP_Store::instance()->get_settings();
        if ( empty( $settings['force_from'] ) ) {
            return $name;
        }
        $acc = $this->resolve_current_account();
        if ( $acc && ! empty( $acc['from_name'] ) ) {
            return $acc['from_name'];
        }
        return $name;
    }

    private function resolve_current_account() {
        if ( $this->current_account_id !== '' ) {
            $acc = SMTPWP_Store::instance()->get_account( $this->current_account_id );
            if ( $acc ) {
                return $acc;
            }
        }
        $ordered = SMTPWP_Store::instance()->get_ordered_accounts();
        // NOTE: get_ordered_accounts advances round-robin counter; only call when needed.
        // Here we peek at first without advancing twice: just return first default.
        return ! empty( $ordered ) ? $ordered[0] : null;
    }

    public function configure_phpmailer( $phpmailer ) {
        // If a retry chain is active, use the head of the queue.
        if ( ! empty( $this->try_queue ) ) {
            $account = array_shift( $this->try_queue );
            $full = SMTPWP_Store::instance()->get_account( $account['id'] );
            if ( $full ) {
                $account = $full;
            }
        } else {
            $ordered = SMTPWP_Store::instance()->get_ordered_accounts();
            if ( empty( $ordered ) ) {
                return; // No SMTP accounts -> leave default mailer.
            }
            $account = $ordered[0];
            // Store the rest for potential failover.
            $this->try_queue = array_slice( $ordered, 1 );
        }

        $this->current_account_id = $account['id'];
        $this->send_seq++;
        $this->current_seq = $this->send_seq;
        $this->apply_to_phpmailer( $phpmailer, $account );
    }

    public function apply_to_phpmailer( $phpmailer, $account ) {
        $phpmailer->isSMTP();
        $phpmailer->Host       = $account['host'];
        $phpmailer->Port       = intval( $account['port'] );
        $phpmailer->SMTPAuth   = ! empty( $account['auth'] );
        if ( $phpmailer->SMTPAuth ) {
            $phpmailer->Username = $account['username'];
            $phpmailer->Password = SMTPWP_Crypto::decrypt( $account['password'] );
        }
        $enc = isset( $account['encryption'] ) ? $account['encryption'] : 'tls';
        if ( $enc === 'ssl' ) {
            $phpmailer->SMTPSecure = 'ssl';
        } elseif ( $enc === 'tls' ) {
            $phpmailer->SMTPSecure = 'tls';
        } else {
            $phpmailer->SMTPSecure = '';
            $phpmailer->SMTPAutoTLS = false;
        }
        // Gmail-friendly defaults.
        $phpmailer->Timeout = 15;
        $phpmailer->SMTPKeepAlive = false;

        $settings = SMTPWP_Store::instance()->get_settings();
        if ( ! empty( $settings['debug'] ) ) {
            $phpmailer->SMTPDebug = 2;
            $phpmailer->Debugoutput = function ( $str, $level ) {
                error_log( '[SMTPWP] ' . $str );
            };
        }

        if ( ! empty( $account['from_email'] ) && is_email( $account['from_email'] ) ) {
            $phpmailer->setFrom(
                $account['from_email'],
                ! empty( $account['from_name'] ) ? $account['from_name'] : $account['from_email'],
                false
            );
            if ( ! empty( $settings['force_from'] ) ) {
                $phpmailer->Sender = $account['from_email'];
            }
        }

        // Reply-To per account (fallback: none = recipient replies to From).
        if ( ! empty( $account['reply_to_email'] ) && is_email( $account['reply_to_email'] ) ) {
            try {
                $phpmailer->clearReplyTos();
                $phpmailer->addReplyTo(
                    $account['reply_to_email'],
                    ! empty( $account['reply_to_name'] ) ? $account['reply_to_name'] : $account['reply_to_email']
                );
            } catch ( Exception $e ) { // phpcs:ignore
                // Ignore reply-to errors, From is already set.
            }
        }

        // Trace which account sent it.
        try {
            $phpmailer->addCustomHeader( 'X-SMTPWP-Account', isset( $account['id'] ) ? $account['id'] : '' );
        } catch ( Exception $e ) { // phpcs:ignore
        }

        // Coverage safety net: PHPMailer calls this after every send().
        // We only record here; wp_mail_succeeded/failed do the real logging
        // (with full error detail). Anything left unreported is flushed on shutdown.
        try {
            $phpmailer->action_function = array( $this, 'phpmailer_action' );
        } catch ( Exception $e ) { // phpcs:ignore
        }
    }

    /**
     * PHPMailer send callback. Signature fixed by PHPMailer:
     * ($result, $to, $cc, $bcc, $subject, $body, $from, $extra).
     */
    public function phpmailer_action( $result, $to, $cc, $bcc, $subject, $body, $from, $extra = array() ) {
        $seq = $this->current_seq;
        if ( $seq <= 0 || isset( $this->logged_seqs[ $seq ] ) ) {
            return;
        }
        $this->cb_pending[ $seq ] = array(
            'result'  => ! empty( $result ),
            'to'      => $to,
            'subject' => $subject,
            'body'    => is_string( $body ) ? $body : '',
            'from'    => is_string( $from ) ? $from : '',
        );
    }

    /**
     * Log any PHPMailer send that never reached wp_mail_succeeded/failed.
     * Runs on shutdown and before each new configuration.
     */
    public function flush_pending() {
        if ( empty( $this->cb_pending ) ) {
            return;
        }
        foreach ( $this->cb_pending as $seq => $info ) {
            if ( isset( $this->logged_seqs[ $seq ] ) ) {
                unset( $this->cb_pending[ $seq ] );
                continue;
            }
            $acc = SMTPWP_Store::instance()->get_account( $this->current_account_id );
            SMTPWP_Logger::instance()->log(
                $info['to'],
                $info['subject'],
                $this->current_account_id,
                $acc ? $acc['label'] : '',
                $info['result'] ? 'sent' : 'failed',
                $info['result']
                    ? __( 'Reported via PHPMailer callback (wp_mail hooks did not fire).', 'smtpwp' )
                    : __( 'Failed via PHPMailer callback (wp_mail hooks did not fire).', 'smtpwp' ),
                isset( $info['body'] ) ? $info['body'] : '',
                '',
                isset( $info['from'] ) ? $info['from'] : ( $acc && ! empty( $acc['from_email'] ) ? $acc['from_email'] : '' )
            );
            $this->logged_seqs[ $seq ] = true;
            unset( $this->cb_pending[ $seq ] );
        }
    }

    public function on_succeeded( $mail_data ) {
        // Already logged via pre_wp_mail observer (another plugin handled it).
        if ( $this->pre_handled ) {
            $this->pre_handled = false;
            $this->try_queue = array();
            $this->retrying = false;
            return;
        }
        $to      = isset( $mail_data['to'] ) ? $mail_data['to'] : '';
        $subject = isset( $mail_data['subject'] ) ? $mail_data['subject'] : '';
        $message = '';
        $headers = '';
        // Fallback to captured args.
        if ( $this->last_mail ) {
            if ( empty( $to ) && isset( $this->last_mail['to'] ) ) {
                $to = $this->last_mail['to'];
            }
            if ( empty( $subject ) && isset( $this->last_mail['subject'] ) ) {
                $subject = $this->last_mail['subject'];
            }
            $message = isset( $this->last_mail['message'] ) ? $this->last_mail['message'] : '';
            $headers = isset( $this->last_mail['headers'] ) ? $this->last_mail['headers'] : '';
        }
        $acc = SMTPWP_Store::instance()->get_account( $this->current_account_id );
        SMTPWP_Logger::instance()->log(
            $to,
            $subject,
            $this->current_account_id,
            $acc ? $acc['label'] : '',
            'sent',
            '',
            $message,
            $headers,
            $acc && ! empty( $acc['from_email'] ) ? $acc['from_email'] : ''
        );
        // Mark handled so the shutdown safety net skips this send.
        if ( $this->current_seq > 0 ) {
            $this->logged_seqs[ $this->current_seq ] = true;
            unset( $this->cb_pending[ $this->current_seq ] );
        }
        // Reset queue after success.
        $this->try_queue = array();
        $this->retrying = false;
    }

    public function on_failed( $wp_error ) {
        // Already logged via pre_wp_mail observer (another plugin handled it).
        if ( $this->pre_handled ) {
            $this->pre_handled = false;
            $this->try_queue = array();
            $this->retrying = false;
            return;
        }
        $to      = '';
        $subject = '';
        $message = '';
        $headers = array();
        $attachments = array();
        if ( $this->last_mail ) {
            $to          = isset( $this->last_mail['to'] ) ? $this->last_mail['to'] : '';
            $subject     = isset( $this->last_mail['subject'] ) ? $this->last_mail['subject'] : '';
            $message     = isset( $this->last_mail['message'] ) ? $this->last_mail['message'] : '';
            $headers     = isset( $this->last_mail['headers'] ) ? $this->last_mail['headers'] : array();
            $attachments = isset( $this->last_mail['attachments'] ) ? $this->last_mail['attachments'] : array();
        }

        $acc = SMTPWP_Store::instance()->get_account( $this->current_account_id );
        $err = is_wp_error( $wp_error ) ? $wp_error->get_error_message() : 'Unknown error';

        // If there are more accounts to try -> retry with next account.
        if ( ! $this->retrying && ! empty( $this->try_queue ) && $this->last_mail ) {
            // Log this attempt as failed, then retry.
            SMTPWP_Logger::instance()->log(
                $to,
                $subject,
                $this->current_account_id,
                $acc ? $acc['label'] : '',
                'failed',
                'Attempt failed, trying next account. Error: ' . $err,
                $message,
                $headers,
                $acc && ! empty( $acc['from_email'] ) ? $acc['from_email'] : ''
            );
            $this->retrying = true;
            // configure_phpmailer will shift the next account from try_queue.
            if ( $this->current_seq > 0 ) {
                $this->logged_seqs[ $this->current_seq ] = true;
                unset( $this->cb_pending[ $this->current_seq ] );
            }
            $result = wp_mail( $to, $subject, $message, $headers, $attachments );
            $this->retrying = false;
            // The recursive wp_mail triggers its own succeeded/failed hooks.
            return;
        }

        // No more accounts (or already retrying): final failure log.
        SMTPWP_Logger::instance()->log(
            $to,
            $subject,
            $this->current_account_id,
            $acc ? $acc['label'] : '',
            'failed',
            $err,
            $message,
            $headers,
            $acc && ! empty( $acc['from_email'] ) ? $acc['from_email'] : ''
        );
        if ( $this->current_seq > 0 ) {
            $this->logged_seqs[ $this->current_seq ] = true;
            unset( $this->cb_pending[ $this->current_seq ] );
        }
        $this->try_queue = array();
        $this->retrying = false;
    }

    /**
     * Direct send used by the Test Email tool (tries accounts in order until one works).
     *
     * @return array { success: bool, account: ?array, error: string }
     */
    public function send_test( $to, $subject, $message, $account_id = '' ) {
        $store = SMTPWP_Store::instance();
        if ( $account_id !== '' ) {
            $one = $store->get_account( $account_id );
            if ( ! $one ) {
                // Fallback: try case-insensitive match (should already be handled, but be safe).
                foreach ( $store->get_accounts() as $key => $acc ) {
                    if ( strtolower( (string) $key ) === strtolower( (string) $account_id ) ) {
                        $one = $acc;
                        break;
                    }
                }
            }
            if ( ! $one ) {
                return array( 'success' => false, 'account' => null, 'error' => __( 'Selected account not found. Please refresh the page and try again.', 'smtpwp' ) );
            }
            if ( empty( $one['is_active'] ) ) {
                return array( 'success' => false, 'account' => null, 'error' => sprintf( __( 'Account "%s" is disabled. Enable it first.', 'smtpwp' ), $one['label'] ) );
            }
            $ordered = array( $one );
        } else {
            $ordered = $store->get_ordered_accounts();
        }
        if ( empty( $ordered ) ) {
            $total = count( $store->get_accounts() );
            if ( $total > 0 ) {
                return array( 'success' => false, 'account' => null, 'error' => __( 'All SMTP accounts are disabled. Enable at least one account.', 'smtpwp' ) );
            }
            return array( 'success' => false, 'account' => null, 'error' => __( 'No SMTP accounts found. Add one first.', 'smtpwp' ) );
        }
        $last_error = '';
        foreach ( $ordered as $account ) {
            $ok = wp_mail( $to, $subject, $message );
            if ( $ok ) {
                return array( 'success' => true, 'account' => $account, 'error' => '' );
            }
            $last_error = 'Failed with account ' . $account['label'];
            // Break after first if a specific account was requested.
            if ( $account_id !== '' ) {
                break;
            }
            // Otherwise wp_mail_failed handler already retried the chain,
            // so stop to avoid double-sending.
            break;
        }
        return array( 'success' => false, 'account' => null, 'error' => $last_error );
    }
}
