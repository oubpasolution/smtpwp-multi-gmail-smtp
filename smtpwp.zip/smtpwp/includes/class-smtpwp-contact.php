<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SMTPWP_Contact {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        add_shortcode( 'smtpwp_contact', array( $this, 'shortcode' ) );
        add_shortcode( 'smtpwp_contact_form', array( $this, 'shortcode' ) );
        add_action( 'init', array( $this, 'handle_submit' ) );
    }

    public function recipient() {
        $to = apply_filters( 'smtpwp_contact_recipient', get_option( 'admin_email' ) );
        return is_email( $to ) ? $to : get_option( 'admin_email' );
    }

    public function shortcode( $atts ) {
        $atts = shortcode_atts( array(
            'title'  => __( 'Contact us', 'smtpwp' ),
            'button' => __( 'Send message', 'smtpwp' ),
        ), $atts, 'smtpwp_contact' );

        $sent = isset( $_GET['smtpwp_sent'] ) ? sanitize_key( $_GET['smtpwp_sent'] ) : '';
        $out  = '<div class="smtpwp-contact">';
        if ( $sent === 'ok' ) {
            $out .= '<p class="smtpwp-contact-ok">' . esc_html__( 'Message sent. We will reply soon.', 'smtpwp' ) . '</p>';
        } elseif ( $sent === 'fail' ) {
            $out .= '<p class="smtpwp-contact-fail">' . esc_html__( 'Sending failed. Please try again.', 'smtpwp' ) . '</p>';
        }
        $out .= '<form method="post" action="' . esc_url( remove_query_arg( 'smtpwp_sent' ) ) . '">';
        $out .= wp_nonce_field( 'smtpwp_contact', '_smtpwp_contact_nonce', true, false );
        $out .= '<p><label>' . esc_html__( 'Name', 'smtpwp' ) . '<br><input type="text" name="smtpwp_name" required maxlength="100"></label></p>';
        $out .= '<p><label>' . esc_html__( 'Email', 'smtpwp' ) . '<br><input type="email" name="smtpwp_email" required maxlength="200"></label></p>';
        $out .= '<p><label>' . esc_html__( 'Subject', 'smtpwp' ) . '<br><input type="text" name="smtpwp_subject" required maxlength="200" value="' . esc_attr( $atts['title'] ) . '"></label></p>';
        $out .= '<p><label>' . esc_html__( 'Message', 'smtpwp' ) . '<br><textarea name="smtpwp_message" rows="6" required maxlength="5000"></textarea></label></p>';
        // Honeypot.
        $out .= '<p style="display:none"><label>Leave empty<input type="text" name="smtpwp_website" value=""></label></p>';
        $out .= '<p><button type="submit" name="smtpwp_contact_send" value="1" class="button button-primary">' . esc_html( $atts['button'] ) . '</button></p>';
        $out .= '</form></div>';
        return $out;
    }

    public function handle_submit() {
        if ( empty( $_POST['smtpwp_contact_send'] ) ) {
            return;
        }
        if ( ! isset( $_POST['_smtpwp_contact_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['_smtpwp_contact_nonce'] ) ), 'smtpwp_contact' ) ) {
            return;
        }
        // Honeypot: bots fill it.
        if ( ! empty( $_POST['smtpwp_website'] ) ) {
            return;
        }
        $name    = isset( $_POST['smtpwp_name'] ) ? sanitize_text_field( wp_unslash( $_POST['smtpwp_name'] ) ) : '';
        $email   = isset( $_POST['smtpwp_email'] ) ? sanitize_email( wp_unslash( $_POST['smtpwp_email'] ) ) : '';
        $subject = isset( $_POST['smtpwp_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['smtpwp_subject'] ) ) : '';
        $message = isset( $_POST['smtpwp_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['smtpwp_message'] ) ) : '';
        if ( $name === '' || ! is_email( $email ) || $subject === '' || $message === '' ) {
            wp_safe_redirect( add_query_arg( 'smtpwp_sent', 'fail', remove_query_arg( 'smtpwp_sent' ) ) );
            exit;
        }
        $to   = $this->recipient();
        $body = sprintf( "Name: %s\nEmail: %s\nPage: %s\n\n%s", $name, $email, esc_url_raw( wp_get_referer() ), $message );
        $headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );
        $ok = wp_mail( $to, '[Contact] ' . $subject, $body, $headers );
        wp_safe_redirect( add_query_arg( 'smtpwp_sent', $ok ? 'ok' : 'fail', remove_query_arg( 'smtpwp_sent' ) ) );
        exit;
    }
}
