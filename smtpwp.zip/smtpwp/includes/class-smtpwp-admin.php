<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SMTPWP_Admin {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    const LOG_PER_PAGE = 20;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
        add_action( 'admin_post_smtpwp_save_account', array( $this, 'handle_save_account' ) );
        add_action( 'admin_post_smtpwp_save_settings', array( $this, 'handle_save_settings' ) );
        add_action( 'admin_post_smtpwp_export_log', array( $this, 'handle_export_log' ) );
        add_action( 'wp_ajax_smtpwp_test', array( $this, 'ajax_test' ) );
        add_action( 'wp_ajax_smtpwp_delete', array( $this, 'ajax_delete' ) );
        add_action( 'wp_ajax_smtpwp_toggle', array( $this, 'ajax_toggle' ) );
        add_action( 'wp_ajax_smtpwp_set_default', array( $this, 'ajax_set_default' ) );
        add_action( 'wp_ajax_smtpwp_log', array( $this, 'ajax_log' ) );
        add_action( 'wp_ajax_smtpwp_log_view', array( $this, 'ajax_log_view' ) );
    }

    public function menu() {
        add_options_page(
            __( 'SMTPWP - Multi Gmail SMTP', 'smtpwp' ),
            __( 'SMTP Gmail', 'smtpwp' ),
            'manage_options',
            'smtpwp',
            array( $this, 'render' )
        );
    }

    public function assets( $hook ) {
        if ( $hook !== 'settings_page_smtpwp' ) {
            return;
        }
        wp_enqueue_style( 'smtpwp-admin', SMTPWP_URL . 'assets/admin.css', array(), SMTPWP_VERSION );
        wp_enqueue_script( 'smtpwp-admin', SMTPWP_URL . 'assets/admin.js', array( 'jquery' ), SMTPWP_VERSION, true );
        wp_localize_script( 'smtpwp-admin', 'SMTPWP', array(
            'ajax'  => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce( 'smtpwp_ajax' ),
        ) );
    }

    private function sanitize_id( $id ) {
        $id = (string) $id;
        $id = preg_replace( '/[^A-Za-z0-9_\-]/', '', $id );
        return substr( $id, 0, 64 );
    }

    public function handle_save_account() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Forbidden', 'smtpwp' ) );
        }
        check_admin_referer( 'smtpwp_save_account' );

        $data = array(
            'id'             => isset( $_POST['id'] ) ? $this->sanitize_id( wp_unslash( $_POST['id'] ) ) : '',
            'label'          => isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '',
            'from_name'      => isset( $_POST['from_name'] ) ? sanitize_text_field( wp_unslash( $_POST['from_name'] ) ) : '',
            'from_email'     => isset( $_POST['from_email'] ) ? sanitize_email( wp_unslash( $_POST['from_email'] ) ) : '',
            'reply_to_name'  => isset( $_POST['reply_to_name'] ) ? sanitize_text_field( wp_unslash( $_POST['reply_to_name'] ) ) : '',
            'reply_to_email' => isset( $_POST['reply_to_email'] ) ? sanitize_email( wp_unslash( $_POST['reply_to_email'] ) ) : '',
            'host'       => isset( $_POST['host'] ) ? sanitize_text_field( wp_unslash( $_POST['host'] ) ) : 'smtp.gmail.com',
            'port'       => isset( $_POST['port'] ) ? intval( $_POST['port'] ) : 587,
            'encryption' => isset( $_POST['encryption'] ) ? sanitize_key( $_POST['encryption'] ) : 'tls',
            'auth'       => ! empty( $_POST['auth'] ) ? 1 : 0,
            'username'   => isset( $_POST['username'] ) ? sanitize_text_field( wp_unslash( $_POST['username'] ) ) : '',
            'password'   => isset( $_POST['password'] ) ? (string) $_POST['password'] : '',
            'is_active'  => ! empty( $_POST['is_active'] ) ? 1 : 0,
            'is_default' => ! empty( $_POST['is_default'] ) ? 1 : 0,
        );

        if ( ! is_email( $data['from_email'] ) ) {
            $this->redirect_error( __( 'Please enter a valid From Email.', 'smtpwp' ) );
        }
        if ( $data['auth'] && $data['username'] === '' ) {
            $this->redirect_error( __( 'Username (Gmail address) is required when Auth is enabled.', 'smtpwp' ) );
        }

        SMTPWP_Store::instance()->save_account( $data );
        $this->redirect_ok( __( 'SMTP account saved.', 'smtpwp' ) );
    }

    public function handle_save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Forbidden', 'smtpwp' ) );
        }
        check_admin_referer( 'smtpwp_save_settings' );
        $settings = array(
            'strategy'        => isset( $_POST['strategy'] ) ? sanitize_key( $_POST['strategy'] ) : 'failover',
            'default_account' => isset( $_POST['default_account'] ) ? $this->sanitize_id( wp_unslash( $_POST['default_account'] ) ) : '',
            'log_enabled'     => ! empty( $_POST['log_enabled'] ) ? 1 : 0,
            'log_retention'   => isset( $_POST['log_retention'] ) ? intval( $_POST['log_retention'] ) : 30,
            'debug'           => ! empty( $_POST['debug'] ) ? 1 : 0,
            'force_from'      => ! empty( $_POST['force_from'] ) ? 1 : 0,
        );
        SMTPWP_Store::instance()->update_settings( $settings );
        if ( $settings['default_account'] !== '' ) {
            $ok = SMTPWP_Store::instance()->set_default( $settings['default_account'] );
            if ( ! $ok ) {
                // Stale ID (e.g. account deleted in another tab) — reset to automatic.
                SMTPWP_Store::instance()->update_settings( array( 'default_account' => '' ) );
            }
        }
        // Clear log if requested.
        if ( ! empty( $_POST['clear_log'] ) ) {
            SMTPWP_Logger::instance()->clear_logs();
        }
        $this->redirect_ok( __( 'Settings saved.', 'smtpwp' ), 'settings' );
    }

    private function redirect_ok( $msg, $tab = 'accounts' ) {
        wp_safe_redirect( add_query_arg( array(
            'page'          => 'smtpwp',
            'tab'           => $tab,
            'smtpwp_notice' => 'ok',
            'smtpwp_msg'    => rawurlencode( $msg ),
        ), admin_url( 'options-general.php' ) ) );
        exit;
    }

    private function redirect_error( $msg, $tab = 'accounts' ) {
        wp_safe_redirect( add_query_arg( array(
            'page'          => 'smtpwp',
            'tab'           => $tab,
            'smtpwp_notice' => 'error',
            'smtpwp_msg'    => rawurlencode( $msg ),
        ), admin_url( 'options-general.php' ) ) );
        exit;
    }

    private function check_ajax() {
        check_ajax_referer( 'smtpwp_ajax', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Forbidden', 'smtpwp' ) ) );
        }
    }

    public function ajax_test() {
        $this->check_ajax();
        $to = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : '';
        $account_id = isset( $_POST['account_id'] ) ? $this->sanitize_id( wp_unslash( $_POST['account_id'] ) ) : '';
        $subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
        $message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
        if ( ! is_email( $to ) ) {
            wp_send_json_error( array( 'message' => __( 'Enter a valid recipient email.', 'smtpwp' ) ) );
        }
        if ( $subject === '' ) {
            $subject = __( 'SMTPWP Test Email', 'smtpwp' ) . ' - ' . date_i18n( 'Y-m-d H:i:s' );
        }
        if ( $message === '' ) {
            $message = __( 'If you received this, your Gmail SMTP account is working.', 'smtpwp' )
                . "\n\nSite: " . get_bloginfo( 'name' ) . ' (' . home_url() . ')'
                . "\nTime: " . current_time( 'mysql' );
        }
        $res = SMTPWP_Mailer::instance()->send_test( $to, $subject, $message, $account_id );
        if ( $res['success'] ) {
            wp_send_json_success( array( 'message' => sprintf( __( 'Test email sent via "%s". Check inbox/spam.', 'smtpwp' ), $res['account']['label'] ) ) );
        }
        wp_send_json_error( array( 'message' => $res['error'] . ' ' . __( 'Check Email Log tab for details.', 'smtpwp' ) ) );
    }

    public function ajax_delete() {
        $this->check_ajax();
        $id = isset( $_POST['id'] ) ? $this->sanitize_id( wp_unslash( $_POST['id'] ) ) : '';
        $ok = SMTPWP_Store::instance()->delete_account( $id );
        if ( $ok ) {
            wp_send_json_success();
        }
        wp_send_json_error( array( 'message' => __( 'Account not found.', 'smtpwp' ) ) );
    }

    public function ajax_toggle() {
        $this->check_ajax();
        $id = isset( $_POST['id'] ) ? $this->sanitize_id( wp_unslash( $_POST['id'] ) ) : '';
        $ok = SMTPWP_Store::instance()->toggle_active( $id );
        if ( $ok ) {
            wp_send_json_success();
        }
        wp_send_json_error( array( 'message' => __( 'Account not found.', 'smtpwp' ) ) );
    }

    public function ajax_log_view() {
        $this->check_ajax();
        $id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
        if ( $id <= 0 ) {
            wp_send_json_error( array( 'message' => __( 'Invalid email ID.', 'smtpwp' ) ) );
        }
        $row = SMTPWP_Logger::instance()->get_log( $id );
        if ( ! $row ) {
            wp_send_json_error( array( 'message' => __( 'Email not found.', 'smtpwp' ) ) );
        }
        wp_send_json_success( array(
            'id'            => intval( $row['id'] ),
            'created_at'    => (string) $row['created_at'],
            'to_email'      => (string) $row['to_email'],
            'from_email'    => isset( $row['from_email'] ) ? (string) $row['from_email'] : '',
            'subject'       => (string) $row['subject'],
            'account_label' => (string) ( $row['account_label'] !== '' ? $row['account_label'] : $row['account_id'] ),
            'status'        => (string) $row['status'],
            'error_message' => (string) $row['error_message'],
            'headers'       => isset( $row['headers'] ) ? (string) $row['headers'] : '',
            'message'       => isset( $row['message'] ) ? (string) $row['message'] : '',
        ) );
    }

    public function ajax_set_default() {
        $this->check_ajax();
        $id = isset( $_POST['id'] ) ? $this->sanitize_id( wp_unslash( $_POST['id'] ) ) : '';
        $ok = SMTPWP_Store::instance()->set_default( $id );
        if ( $ok ) {
            wp_send_json_success();
        }
        wp_send_json_error( array( 'message' => __( 'Account not found.', 'smtpwp' ) ) );
    }

    public function ajax_log() {
        $this->check_ajax();
        $page = isset( $_POST['page'] ) ? max( 1, intval( $_POST['page'] ) ) : 1;
        $per  = self::LOG_PER_PAGE; // fixed 20 per page
        $total = SMTPWP_Logger::instance()->count_logs();
        $pages = max( 1, (int) ceil( $total / $per ) );
        $page  = min( $page, $pages );
        $rows  = SMTPWP_Logger::instance()->get_logs( $per, ( $page - 1 ) * $per );
        if ( ! is_array( $rows ) ) {
            $rows = array();
        }
        // Trim payload: only fields the table needs.
        $clean = array();
        foreach ( $rows as $r ) {
            $clean[] = array(
                'id'            => intval( $r['id'] ),
                'created_at'    => (string) $r['created_at'],
                'account_label' => (string) ( $r['account_label'] !== '' ? $r['account_label'] : $r['account_id'] ),
                'to_email'      => (string) $r['to_email'],
                'subject'       => (string) $r['subject'],
                'status'        => (string) $r['status'],
                'error_message' => mb_substr( (string) $r['error_message'], 0, 300 ),
            );
        }
        wp_send_json_success( array(
            'rows'  => $clean,
            'page'  => $page,
            'pages' => $pages,
            'total' => $total,
            'per'   => $per,
        ) );
    }

    public function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- tab navigation only.
        $tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'accounts';
        $allowed = array( 'accounts', 'settings', 'log', 'test', 'help', 'pro' );
        if ( ! in_array( $tab, $allowed, true ) ) {
            $tab = 'accounts';
        }
        $store    = SMTPWP_Store::instance();
        $accounts = $store->get_accounts();
        $settings = $store->get_settings();
        $default_acc = $store->get_default_account();
        $active_count = count( $store->get_active_accounts() );
        $total_count  = count( $accounts );
        $log_count    = SMTPWP_Logger::instance()->count_logs();
        $last_logs    = SMTPWP_Logger::instance()->get_logs( 1, 0 );
        $last_status  = ! empty( $last_logs ) ? $last_logs[0]['status'] : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- notice display only.
        $notice = isset( $_GET['smtpwp_notice'] ) ? sanitize_key( $_GET['smtpwp_notice'] ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- notice display only.
        $msg = isset( $_GET['smtpwp_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['smtpwp_msg'] ) ) : '';

        // Edit target.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- edit navigation only.
        $edit_id = isset( $_GET['edit'] ) ? $this->sanitize_id( wp_unslash( $_GET['edit'] ) ) : '';
        $editing = $edit_id !== '' ? $store->get_account( $edit_id ) : null;

        include SMTPWP_DIR . 'templates/admin-page.php';
    }

    public function handle_export_log() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Forbidden', 'smtpwp' ) );
        }
        check_admin_referer( 'smtpwp_export_log' );
        $logs = SMTPWP_Logger::instance()->get_logs( 5000, 0 );
        if ( ! is_array( $logs ) ) {
            $logs = array();
        }
        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=smtpwp-log-' . date( 'Y-m-d' ) . '.csv' );
        $out = fopen( 'php://output', 'w' );
        fputcsv( $out, array( 'ID', 'Date', 'To', 'Subject', 'Account ID', 'Account / Sender', 'Status', 'Error' ) );
        foreach ( $logs as $row ) {
            fputcsv( $out, array(
                $row['id'],
                $row['created_at'],
                $row['to_email'],
                $row['subject'],
                $row['account_id'],
                $row['account_label'],
                $row['status'],
                $row['error_message'],
            ) );
        }
        fclose( $out );
        exit;
    }
}
