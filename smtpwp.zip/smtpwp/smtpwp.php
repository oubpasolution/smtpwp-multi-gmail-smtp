<?php
/**
 * Plugin Name:       SMTPWP - Multi Gmail SMTP
 * Plugin URI:        https://oubpa.com/shop
 * Description:       Send WordPress emails via Gmail SMTP. Add unlimited Gmail / Google Workspace SMTP accounts with failover, round-robin and random sending, test emails and email log.
 * Version:           1.1.9
 * Requires at least: 5.7
 * Requires PHP:      7.4
 * Author:            Themestar Teams
 * Author URI:        https://oubpa.com/contact
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       smtpwp
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SMTPWP_VERSION', '1.1.9' );
define( 'SMTPWP_FILE', __FILE__ );
define( 'SMTPWP_DIR', plugin_dir_path( __FILE__ ) );
define( 'SMTPWP_URL', plugin_dir_url( __FILE__ ) );
define( 'SMTPWP_OPTION_ACCOUNTS', 'smtpwp_accounts' );
define( 'SMTPWP_OPTION_SETTINGS', 'smtpwp_settings' );
define( 'SMTPWP_OPTION_RR_INDEX', 'smtpwp_rr_index' );

require_once SMTPWP_DIR . 'includes/class-smtpwp-crypto.php';
require_once SMTPWP_DIR . 'includes/class-smtpwp-store.php';
require_once SMTPWP_DIR . 'includes/class-smtpwp-logger.php';
require_once SMTPWP_DIR . 'includes/class-smtpwp-mailer.php';
require_once SMTPWP_DIR . 'includes/class-smtpwp-contact.php';
require_once SMTPWP_DIR . 'includes/class-smtpwp-admin.php';

function smtpwp() {
    return SMTPWP_Store::instance();
}

function smtpwp_boot() {
    SMTPWP_Logger::instance();
    SMTPWP_Mailer::instance();
    SMTPWP_Contact::instance();
    if ( is_admin() ) {
        SMTPWP_Admin::instance();
    }
}
add_action( 'plugins_loaded', 'smtpwp_boot' );

register_activation_hook( __FILE__, array( 'SMTPWP_Logger', 'activate' ) );
