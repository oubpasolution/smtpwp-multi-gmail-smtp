<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SMTPWP_Store {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function default_settings() {
        return array(
            'strategy'         => 'failover', // failover | round_robin | random
            'default_account'  => '',
            'log_enabled'      => 1,
            'log_retention'    => 30, // days, 0 = forever
            'debug'            => 0,
            'force_from'       => 1,
        );
    }

    public function get_settings() {
        $saved = get_option( SMTPWP_OPTION_SETTINGS, array() );
        return wp_parse_args( is_array( $saved ) ? $saved : array(), $this->default_settings() );
    }

    public function update_settings( $settings ) {
        $current = $this->get_settings();
        $merged  = wp_parse_args( $settings, $current );
        $merged['strategy']        = in_array( $merged['strategy'], array( 'failover', 'round_robin', 'random' ), true ) ? $merged['strategy'] : 'failover';
        $merged['log_enabled']     = ! empty( $merged['log_enabled'] ) ? 1 : 0;
        $merged['debug']           = ! empty( $merged['debug'] ) ? 1 : 0;
        $merged['force_from']      = ! empty( $merged['force_from'] ) ? 1 : 0;
        $merged['log_retention']   = max( 0, intval( $merged['log_retention'] ) );
        $merged['default_account'] = $this->sanitize_id( $merged['default_account'] );
        update_option( SMTPWP_OPTION_SETTINGS, $merged );
        return $merged;
    }

    public function get_accounts() {
        $accounts = get_option( SMTPWP_OPTION_ACCOUNTS, array() );
        if ( ! is_array( $accounts ) ) {
            return array();
        }
        return $accounts;
    }

    public function get_account( $id ) {
        $accounts = $this->get_accounts();
        if ( isset( $accounts[ $id ] ) ) {
            return $accounts[ $id ];
        }
        // Case-insensitive fallback for IDs created before 1.0.1 (sanitize_key lowercased lookups).
        foreach ( $accounts as $key => $acc ) {
            if ( strtolower( (string) $key ) === strtolower( (string) $id ) ) {
                return $acc;
            }
        }
        return null;
    }

    public function get_active_accounts() {
        return array_values( array_filter( $this->get_accounts(), function ( $a ) {
            return ! empty( $a['is_active'] );
        } ) );
    }

    public function sanitize_id( $id ) {
        $id = (string) $id;
        $id = preg_replace( '/[^A-Za-z0-9_\-]/', '', $id );
        return substr( $id, 0, 64 );
    }

    public function save_account( $data ) {
        $accounts = $this->get_accounts();

        $raw_id = ! empty( $data['id'] ) ? $this->sanitize_id( $data['id'] ) : '';
        if ( $raw_id !== '' ) {
            // Exact match first, then case-insensitive match (pre-1.0.1 mixed-case IDs).
            if ( isset( $accounts[ $raw_id ] ) ) {
                $id = $raw_id;
            } else {
                $id = $raw_id;
                foreach ( $accounts as $key => $v ) {
                    if ( strtolower( (string) $key ) === strtolower( $raw_id ) ) {
                        $id = $key;
                        break;
                    }
                }
            }
        } else {
            $id = 'acc_' . strtolower( wp_generate_password( 8, false, false ) );
        }
        $prev = isset( $accounts[ $id ] ) ? $accounts[ $id ] : array();
        $prev_password_enc = isset( $prev['password'] ) ? $prev['password'] : '';

        // Gmail preset defaults.
        $host = isset( $data['host'] ) ? sanitize_text_field( $data['host'] ) : 'smtp.gmail.com';
        $host = $host === '' ? 'smtp.gmail.com' : $host;

        $password_plain = isset( $data['password'] ) ? (string) $data['password'] : '';
        // Empty password on edit => keep old.
        if ( $password_plain === '' && $prev_password_enc !== '' && ! empty( $data['id'] ) ) {
            $password_enc = $prev_password_enc;
        } else {
            $password_enc = SMTPWP_Crypto::encrypt( $password_plain );
        }

        $account = array(
            'id'             => $id,
            'label'          => isset( $data['label'] ) ? sanitize_text_field( $data['label'] ) : '',
            'from_name'      => isset( $data['from_name'] ) ? sanitize_text_field( $data['from_name'] ) : '',
            'from_email'     => isset( $data['from_email'] ) ? sanitize_email( $data['from_email'] ) : '',
            'reply_to_name'  => isset( $data['reply_to_name'] ) ? sanitize_text_field( $data['reply_to_name'] ) : '',
            'reply_to_email' => isset( $data['reply_to_email'] ) ? sanitize_email( $data['reply_to_email'] ) : '',
            'host'        => $host,
            'port'        => isset( $data['port'] ) ? intval( $data['port'] ) : 587,
            'encryption'  => isset( $data['encryption'] ) && in_array( $data['encryption'], array( 'tls', 'ssl', 'none' ), true ) ? $data['encryption'] : 'tls',
            'auth'        => isset( $data['auth'] ) ? ( ! empty( $data['auth'] ) ? 1 : 0 ) : 1,
            'username'    => isset( $data['username'] ) ? sanitize_text_field( $data['username'] ) : '',
            'password'    => $password_enc, // encrypted
            'is_active'   => isset( $data['is_active'] ) ? ( ! empty( $data['is_active'] ) ? 1 : 0 ) : 1,
            'is_default'  => ! empty( $data['is_default'] ) ? 1 : 0,
            'updated_at'  => current_time( 'mysql' ),
        );

        if ( empty( $prev ) ) {
            $account['created_at'] = current_time( 'mysql' );
        } else {
            $account['created_at'] = isset( $prev['created_at'] ) ? $prev['created_at'] : current_time( 'mysql' );
        }

        if ( $account['label'] === '' ) {
            $account['label'] = $account['from_email'] !== '' ? $account['from_email'] : $id;
        }
        if ( $account['port'] <= 0 ) {
            $account['port'] = ( $account['encryption'] === 'ssl' ) ? 465 : 587;
        }

        // Only one default.
        if ( $account['is_default'] ) {
            foreach ( $accounts as $k => $v ) {
                $accounts[ $k ]['is_default'] = 0;
            }
            $settings = $this->get_settings();
            $settings['default_account'] = $id;
            update_option( SMTPWP_OPTION_SETTINGS, $settings );
        }

        $accounts[ $id ] = $account;
        update_option( SMTPWP_OPTION_ACCOUNTS, $accounts );

        // If this is the first account, make it default.
        if ( count( $accounts ) === 1 ) {
            $this->set_default( $id );
        }

        return $account;
    }

    public function resolve_key( $id ) {
        $accounts = $this->get_accounts();
        $id = $this->sanitize_id( $id );
        if ( isset( $accounts[ $id ] ) ) {
            return $id;
        }
        foreach ( $accounts as $key => $v ) {
            if ( strtolower( (string) $key ) === strtolower( $id ) ) {
                return $key;
            }
        }
        return $id;
    }

    public function delete_account( $id ) {
        $id = $this->resolve_key( $id );
        $accounts = $this->get_accounts();
        if ( isset( $accounts[ $id ] ) ) {
            unset( $accounts[ $id ] );
            update_option( SMTPWP_OPTION_ACCOUNTS, $accounts );
            $settings = $this->get_settings();
            if ( $settings['default_account'] === $id ) {
                $settings['default_account'] = '';
                // Promote first remaining active account.
                foreach ( $accounts as $k => $v ) {
                    if ( ! empty( $v['is_active'] ) ) {
                        $settings['default_account'] = $k;
                        $accounts[ $k ]['is_default'] = 1;
                        break;
                    }
                }
                update_option( SMTPWP_OPTION_SETTINGS, $settings );
                update_option( SMTPWP_OPTION_ACCOUNTS, $accounts );
            }
            return true;
        }
        return false;
    }

    public function set_default( $id ) {
        $id = $this->resolve_key( $id );
        $accounts = $this->get_accounts();
        if ( ! isset( $accounts[ $id ] ) ) {
            return false;
        }
        foreach ( $accounts as $k => $v ) {
            $accounts[ $k ]['is_default'] = ( $k === $id ) ? 1 : 0;
        }
        update_option( SMTPWP_OPTION_ACCOUNTS, $accounts );
        $settings = $this->get_settings();
        $settings['default_account'] = $id;
        update_option( SMTPWP_OPTION_SETTINGS, $settings );
        return true;
    }

    public function toggle_active( $id, $active = null ) {
        $id = $this->resolve_key( $id );
        $accounts = $this->get_accounts();
        if ( ! isset( $accounts[ $id ] ) ) {
            return false;
        }
        if ( null === $active ) {
            $active = empty( $accounts[ $id ]['is_active'] );
        }
        $accounts[ $id ]['is_active'] = $active ? 1 : 0;
        update_option( SMTPWP_OPTION_ACCOUNTS, $accounts );
        return true;
    }

    /**
     * Get ordered accounts for the next send based on strategy.
     *
     * @return array
     */
    public function get_ordered_accounts() {
        $settings = $this->get_settings();
        $active   = $this->get_active_accounts();
        if ( empty( $active ) ) {
            return array();
        }

        // Sort: default first for failover.
        usort( $active, function ( $a, $b ) use ( $settings ) {
            $ad = ( ! empty( $a['is_default'] ) || $a['id'] === $settings['default_account'] ) ? 0 : 1;
            $bd = ( ! empty( $b['is_default'] ) || $b['id'] === $settings['default_account'] ) ? 0 : 1;
            return $ad - $bd;
        } );

        $strategy = $settings['strategy'];

        if ( $strategy === 'random' ) {
            shuffle( $active );
            return $active;
        }

        if ( $strategy === 'round_robin' ) {
            $idx = (int) get_option( SMTPWP_OPTION_RR_INDEX, 0 );
            $count = count( $active );
            $ordered = array();
            for ( $i = 0; $i < $count; $i++ ) {
                $ordered[] = $active[ ( $idx + $i ) % $count ];
            }
            update_option( SMTPWP_OPTION_RR_INDEX, ( $idx + 1 ) % $count, false );
            return $ordered;
        }

        // failover: default first, rest as-is.
        return $active;
    }

    public function gmail_preset() {
        return array(
            'host'       => 'smtp.gmail.com',
            'port'       => 587,
            'encryption' => 'tls',
            'auth'       => 1,
        );
    }

    /**
     * Human-readable sender: "From Name <from@email>" + label.
     */
    public function sender_string( $acc ) {
        if ( ! $acc ) {
            return '—';
        }
        $name  = isset( $acc['from_name'] ) ? trim( (string) $acc['from_name'] ) : '';
        $email = isset( $acc['from_email'] ) ? trim( (string) $acc['from_email'] ) : '';
        if ( $name !== '' && $email !== '' ) {
            return $name . ' <' . $email . '>';
        }
        if ( $email !== '' ) {
            return $email;
        }
        if ( $name !== '' ) {
            return $name;
        }
        return isset( $acc['label'] ) ? $acc['label'] : '—';
    }

    public function reply_to_string( $acc ) {
        if ( ! $acc ) {
            return '—';
        }
        $name  = isset( $acc['reply_to_name'] ) ? trim( (string) $acc['reply_to_name'] ) : '';
        $email = isset( $acc['reply_to_email'] ) ? trim( (string) $acc['reply_to_email'] ) : '';
        if ( $email === '' ) {
            return __( 'Same as From', 'smtp-gmail-multi' );
        }
        return $name !== '' ? $name . ' <' . $email . '>' : $email;
    }

    public function get_default_account() {
        $settings = $this->get_settings();
        if ( $settings['default_account'] !== '' ) {
            $acc = $this->get_account( $settings['default_account'] );
            if ( $acc ) {
                return $acc;
            }
        }
        foreach ( $this->get_accounts() as $acc ) {
            if ( ! empty( $acc['is_default'] ) ) {
                return $acc;
            }
        }
        $active = $this->get_active_accounts();
        return ! empty( $active ) ? $active[0] : null;
    }
}
