<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}
global $wpdb;
$smtpwp_table = $wpdb->prefix . 'smtpwp_log';
// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table is a trusted prefixed identifier; no user input.
$wpdb->query( "DROP TABLE IF EXISTS {$smtpwp_table}" );
// phpcs:enable
delete_option( 'smtpwp_accounts' );
delete_option( 'smtpwp_settings' );
delete_option( 'smtpwp_rr_index' );
