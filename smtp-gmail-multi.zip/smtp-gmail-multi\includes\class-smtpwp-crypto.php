<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SMTPWP_Crypto {

    public static function encrypt( $plain ) {
        if ( $plain === '' || $plain === null ) {
            return '';
        }
        $plain = (string) $plain;
        if ( ! function_exists( 'openssl_encrypt' ) ) {
            return base64_encode( 'b64:' . $plain );
        }
        $key = self::key();
        $iv  = openssl_random_pseudo_bytes( openssl_cipher_iv_length( 'aes-256-cbc' ) );
        $enc = openssl_encrypt( $plain, 'aes-256-cbc', $key, 0, $iv );
        if ( $enc === false ) {
            return base64_encode( 'b64:' . $plain );
        }
        return base64_encode( 'enc:' . base64_encode( $iv ) . ':' . $enc );
    }

    public static function decrypt( $stored ) {
        if ( $stored === '' || $stored === null ) {
            return '';
        }
        $raw = base64_decode( $stored, true );
        if ( $raw === false ) {
            return '';
        }
        // Legacy plain base64 fallback.
        if ( strpos( $raw, 'b64:' ) === 0 ) {
            return substr( $raw, 4 );
        }
        if ( strpos( $raw, 'enc:' ) !== 0 ) {
            // Maybe stored plain text from very old version.
            return $stored;
        }
        if ( ! function_exists( 'openssl_decrypt' ) ) {
            return '';
        }
        $parts = explode( ':', $raw, 3 );
        if ( count( $parts ) !== 3 ) {
            return '';
        }
        $iv  = base64_decode( $parts[1], true );
        $enc = $parts[2];
        if ( $iv === false ) {
            return '';
        }
        $dec = openssl_decrypt( $enc, 'aes-256-cbc', self::key(), 0, $iv );
        return $dec === false ? '' : $dec;
    }

    private static function key() {
        $salt = defined( 'AUTH_KEY' ) ? AUTH_KEY : 'smtpwp';
        $salt .= defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : 'smtpwp-secure';
        return hash( 'sha256', $salt, true );
    }
}
