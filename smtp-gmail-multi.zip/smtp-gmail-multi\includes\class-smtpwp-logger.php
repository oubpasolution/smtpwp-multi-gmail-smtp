<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// This class owns a dedicated custom table, so direct, uncached, schema-aware
// queries are intentional. The table name is a trusted, prefixed identifier.
// phpcs:disable WordPress.DB.DirectDatabaseQuery
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

class SMTPWP_Logger {

    private static $instance = null;
    private $table;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'smtpwp_log';
        $this->maybe_upgrade();
    }

    /** Add new columns to installs created before v1.1.5 (activation hook won't re-run). */
    private function maybe_upgrade() {
        global $wpdb;
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $this->table ) ) !== $this->table ) {
            return;
        }
        $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$this->table}", 0 );
        if ( ! is_array( $cols ) ) {
            return;
        }
        if ( ! in_array( 'from_email', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN from_email varchar(200) DEFAULT ''" );
        }
        if ( ! in_array( 'message', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN message mediumtext" );
        }
        if ( ! in_array( 'headers', $cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$this->table} ADD COLUMN headers text" );
        }
    }

    public static function activate() {
        global $wpdb;
        $table = $wpdb->prefix . 'smtpwp_log';
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $sql = "CREATE TABLE $table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            created_at datetime NOT NULL,
            to_email varchar(500) DEFAULT '',
            from_email varchar(200) DEFAULT '',
            subject varchar(500) DEFAULT '',
            account_id varchar(100) DEFAULT '',
            account_label varchar(200) DEFAULT '',
            status varchar(20) DEFAULT '',
            error_message text,
            headers text,
            message mediumtext,
            PRIMARY KEY (id),
            KEY created_at (created_at)
        ) $charset;";
        dbDelta( $sql );
    }

    public function log( $to, $subject, $account_id, $account_label, $status, $error = '', $message = '', $headers = '', $from_email = '' ) {
        $settings = SMTPWP_Store::instance()->get_settings();
        if ( empty( $settings['log_enabled'] ) ) {
            return;
        }
        global $wpdb;
        // Ensure table exists (in case plugin was copied without activation).
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $this->table ) ) !== $this->table ) {
            self::activate();
        }
        if ( is_array( $to ) ) {
            $to = implode( ', ', $to );
        }
        if ( is_array( $headers ) ) {
            $headers = implode( "\n", $headers );
        }
        $wpdb->insert(
            $this->table,
            array(
                'created_at'    => current_time( 'mysql' ),
                'to_email'      => substr( (string) $to, 0, 500 ),
                'from_email'    => substr( (string) $from_email, 0, 200 ),
                'subject'       => substr( (string) $subject, 0, 500 ),
                'account_id'    => substr( (string) $account_id, 0, 100 ),
                'account_label' => substr( (string) $account_label, 0, 200 ),
                'status'        => $status === 'sent' ? 'sent' : 'failed',
                'error_message' => (string) $error,
                'headers'       => substr( (string) $headers, 0, 5000 ),
                'message'       => substr( (string) $message, 0, 100000 ),
            ),
            array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
        );
        $this->maybe_prune();
    }

    private function maybe_prune() {
        $settings = SMTPWP_Store::instance()->get_settings();
        $days = intval( $settings['log_retention'] );
        if ( $days <= 0 ) {
            return;
        }
        global $wpdb;
        // Match the site's local time (created_at is stored via current_time('mysql')).
        $offset = (float) get_option( 'gmt_offset', 0 );
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) + (int) ( $offset * HOUR_IN_SECONDS ) );
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table} WHERE created_at < %s",
                $cutoff
            )
        );
    }

    public function get_logs( $limit = 100, $offset = 0 ) {
        global $wpdb;
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $this->table ) ) !== $this->table ) {
            return array();
        }
        // List view excludes the heavy body columns (fetched per-email via get_log).
        return $wpdb->get_results(
            $wpdb->prepare( "SELECT id, created_at, to_email, from_email, subject, account_id, account_label, status, error_message FROM {$this->table} ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset ),
            ARRAY_A
        );
    }

    public function get_log( $id ) {
        global $wpdb;
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $this->table ) ) !== $this->table ) {
            return null;
        }
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", intval( $id ) ),
            ARRAY_A
        );
    }

    public function count_logs() {
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $this->table ) );
        if ( $exists !== $this->table ) {
            return 0;
        }
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table}" );
    }

    public function clear_logs() {
        global $wpdb;
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $this->table ) ) !== $this->table ) {
            return;
        }
        $wpdb->query( "TRUNCATE TABLE {$this->table}" );
    }
}
