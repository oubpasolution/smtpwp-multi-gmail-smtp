jQuery(function($){
  $('#smtpwp-gmail-preset').on('click', function(){
    $('#smtpwp-host').val('smtp.gmail.com');
    $('#smtpwp-port').val('587');
    $('#smtpwp-enc').val('tls');
    $('input[name="auth"]').prop('checked', true);
  });

  // Show/hide password.
  $('#smtpwp-pass-toggle').on('click', function(){
    var $p = $('#smtpwp-pass');
    var show = $p.attr('type') === 'password';
    $p.attr('type', show ? 'text' : 'password');
    $(this).find('.dashicons').toggleClass('dashicons-visibility dashicons-hidden');
  });

  // Live sender preview in Add/Edit form: "From Name <from@email>".
  function updateFormPreview(){
    var name = $('#smtpwp-from-name').val() || '';
    var email = $('#smtpwp-from-email').val() || '';
    var $box = $('#smtpwp-sender-preview'), $txt = $('#smtpwp-sender-preview-text');
    if (!$box.length) return;
    if (!name && !email) { $box.attr('hidden', true); return; }
    var s = name && email ? name + ' <' + email + '>' : (email || name);
    $txt.text('Recipients will see From: ' + s);
    $box.removeAttr('hidden');
  }
  $('#smtpwp-from-name, #smtpwp-from-email').on('input', updateFormPreview);
  updateFormPreview();

  // Strategy card highlight.
  $('input[name="strategy"]').on('change', function(){
    $('.smtpwp-strat').removeClass('is-sel');
    $(this).closest('.smtpwp-strat').addClass('is-sel');
  });

  function ajax(action, id, onOk){
    $.post(SMTPWP.ajax, { action: action, id: id, nonce: SMTPWP.nonce })
      .done(function(r){ if(r && r.success){ onOk ? onOk(r) : location.reload(); } else { alert((r && r.data && r.data.message) || 'Error'); } })
      .fail(function(){ alert('AJAX error'); });
  }

  $('.smtpwp-delete').on('click', function(){
    if(!confirm('Delete this sender? Emails will use remaining senders.')) return;
    var id = $(this).closest('.smtpwp-acc, tr').data('id');
    ajax('smtpwp_delete', id);
  });
  $('.smtpwp-toggle').on('click', function(){
    var id = $(this).closest('.smtpwp-acc, tr').data('id');
    ajax('smtpwp_toggle', id);
  });
  $('.smtpwp-default').on('click', function(){
    var id = $(this).closest('.smtpwp-acc, tr').data('id');
    ajax('smtpwp_set_default', id);
  });

  // Test tab: live identity preview.
  function updateTestPreview(){
    var $opt = $('#smtpwp-test-acc option:selected');
    var from = $opt.data('sender') || $('#smtpwp-test-acc option[value=""]').data('sender') || '—';
    var reply = $opt.data('reply') || '—';
    $('#smtpwp-prev-from').text(from || '—');
    $('#smtpwp-prev-reply').text(reply || '—');
    $('#smtpwp-prev-to').text($('#smtpwp-test-to').val() || '—');
    $('#smtpwp-prev-subject').text($('#smtpwp-test-subject').val() || '—');
  }
  $('#smtpwp-test-acc, #smtpwp-test-to, #smtpwp-test-subject').on('input change', updateTestPreview);
  updateTestPreview();

  $('#smtpwp-test-send').on('click', function(){
    var $btn = $(this), $res = $('#smtpwp-test-result');
    $btn.prop('disabled', true);
    $res.removeClass('ok err').addClass('sending').text('Sending…');
    $.post(SMTPWP.ajax, {
      action: 'smtpwp_test',
      nonce: SMTPWP.nonce,
      to: $('#smtpwp-test-to').val(),
      account_id: $('#smtpwp-test-acc').val(),
      subject: $('#smtpwp-test-subject').val(),
      message: $('#smtpwp-test-msg').val()
    }).done(function(r){
      if(r && r.success){ $res.removeClass('sending').addClass('ok').text(r.data.message); }
      else { $res.removeClass('sending').addClass('err').text((r && r.data && r.data.message) || 'Failed'); }
    }).fail(function(){ $res.removeClass('sending').addClass('err').text('AJAX error'); })
      .always(function(){ $btn.prop('disabled', false); });
  });

  // ---- Email log: AJAX pagination, 20 per page ----
  function esc(s){ return String(s == null ? '' : s); }
  function renderLogRows(rows){
    var $body = $('#smtpwp-log-body');
    $body.empty();
    if (!rows.length) {
      $body.append($('<tr>').append($('<td colspan="8">').text('No emails on this page.')));
      return;
    }
    rows.forEach(function(r){
      var $tr = $('<tr>');
      $tr.append($('<td>').text(r.id));
      $tr.append($('<td>').addClass('smtpwp-nowrap').text(r.created_at));
      $tr.append($('<td>').append($('<span>').addClass('smtpwp-sender-chip').text(r.account_label)));
      $tr.append($('<td>').text(r.to_email));
      $tr.append($('<td>').text(r.subject));
      var $badge = $('<span>').addClass('smtpwp-badge ' + (r.status === 'sent' ? 'green' : 'red')).text((r.status === 'sent' ? '● sent' : '● failed'));
      $tr.append($('<td>').append($badge));
      $tr.append($('<td>').addClass('smtpwp-err').text(r.error_message || ''));
      var $btn = $('<button>').attr('type', 'button').addClass('button button-small smtpwp-view').attr('data-id', r.id).attr('title', 'View email content');
      $btn.append($('<span>').addClass('dashicons dashicons-visibility'));
      $tr.append($('<td>').append($btn));
      $body.append($tr);
    });
  }
  function renderLogPages(page, pages){
    var $wrap = $('#smtpwp-log-pages');
    if (!$wrap.length) return;
    $wrap.empty();
    if (pages <= 1) return;
    var start = Math.max(1, Math.min(page - 2, pages - 4));
    var end = Math.min(pages, start + 4);
    start = Math.max(1, end - 4);
    for (var i = start; i <= end; i++) {
      (function(n){
        var $b = $('<button>').addClass('button smtpwp-page-btn').attr('data-page', n).text(n);
        if (n === page) { $b.addClass('button-primary'); }
        $b.on('click', function(){ loadLog(n); });
        $wrap.append($b);
      })(i);
    }
  }
  function loadLog(page){
    var $wrap = $('#smtpwp-log-wrap');
    if (!$wrap.length) return;
    var per = 20;
    $('#smtpwp-log-loading').removeAttr('hidden');
    $('#smtpwp-log-prev, #smtpwp-log-next').prop('disabled', true);
    $.post(SMTPWP.ajax, { action: 'smtpwp_log', nonce: SMTPWP.nonce, page: page })
      .done(function(r){
        if (r && r.success) {
          renderLogRows(r.data.rows);
          renderLogPages(r.data.page, r.data.pages);
          $('#smtpwp-log-info').text('Page ' + r.data.page + ' of ' + r.data.pages + ' · ' + r.data.total + ' emails · ' + r.data.per + ' per page');
          $('#smtpwp-log-count').text(r.data.total);
          $('#smtpwp-log-prev').prop('disabled', r.data.page <= 1);
          $('#smtpwp-log-next').prop('disabled', r.data.page >= r.data.pages);
          $wrap.attr('data-page', r.data.page);
          if (window.history && window.history.replaceState) {
            var url = new URL(window.location.href);
            url.searchParams.set('tab', 'log');
            url.searchParams.set('paged', r.data.page);
            window.history.replaceState(null, '', url.toString());
          }
        } else {
          $('#smtpwp-log-info').text((r && r.data && r.data.message) || 'Failed to load log.');
          $('#smtpwp-log-prev, #smtpwp-log-next').prop('disabled', false);
        }
      })
      .fail(function(){ $('#smtpwp-log-info').text('AJAX error loading log.'); })
      .always(function(){ $('#smtpwp-log-loading').attr('hidden', true); });
  }
  $('#smtpwp-log-prev').on('click', function(){ loadLog(parseInt($('#smtpwp-log-wrap').attr('data-page'), 10) - 1 || 1); });
  $('#smtpwp-log-next').on('click', function(){ loadLog(parseInt($('#smtpwp-log-wrap').attr('data-page'), 10) + 1); });

  // ---- Email log: eye button -> view full content in modal ----
  var smtpwpViewHtml = '';
  function openViewModal(){ $('#smtpwp-view-modal').removeAttr('hidden'); }
  function closeViewModal(){ $('#smtpwp-view-modal').attr('hidden', true); $('#smtpwp-v-frame').attr('hidden', true).removeAttr('srcdoc'); $('#smtpwp-v-body').removeAttr('hidden'); $('.smtpwp-view-tab').removeClass('button-primary is-on'); $('.smtpwp-view-tab[data-mode="text"]').addClass('is-on'); }
  $(document).on('click', '.smtpwp-view', function(){
    var id = $(this).data('id');
    $('#smtpwp-v-body').text('Loading…');
    $('#smtpwp-v-error-wrap').attr('hidden', true);
    openViewModal();
    $.post(SMTPWP.ajax, { action: 'smtpwp_log_view', nonce: SMTPWP.nonce, id: id })
      .done(function(r){
        if (!(r && r.success)) { $('#smtpwp-v-body').text((r && r.data && r.data.message) || 'Failed to load.'); return; }
        var d = r.data;
        $('#smtpwp-v-date').text(d.created_at || '—');
        $('#smtpwp-v-from').text((d.from_email ? d.from_email + ' ' : '') + '(' + d.account_label + ')' || '—');
        $('#smtpwp-v-to').text(d.to_email || '—');
        $('#smtpwp-v-subject').text(d.subject || '—');
        $('#smtpwp-v-status').text(d.status || '—');
        if (d.error_message) { $('#smtpwp-v-error').text(d.error_message); $('#smtpwp-v-error-wrap').removeAttr('hidden'); }
        smtpwpViewHtml = d.message || '';
        $('#smtpwp-v-body').text(smtpwpViewHtml !== '' ? smtpwpViewHtml : '(No content stored — this email was logged before v1.1.5.)');
      })
      .fail(function(){ $('#smtpwp-v-body').text('AJAX error.'); });
  });
  $('#smtpwp-view-close').on('click', closeViewModal);
  $('#smtpwp-view-modal').on('click', function(e){ if (e.target === this) closeViewModal(); });
  $(document).on('keydown', function(e){ if (e.key === 'Escape') closeViewModal(); });
  $('.smtpwp-view-tab').on('click', function(){
    $('.smtpwp-view-tab').removeClass('button-primary is-on');
    $(this).addClass('button-primary is-on');
    if ($(this).data('mode') === 'html') {
      $('#smtpwp-v-body').attr('hidden', true);
      $('#smtpwp-v-frame').removeAttr('hidden').attr('srcdoc', smtpwpViewHtml);
    } else {
      $('#smtpwp-v-frame').attr('hidden', true).removeAttr('srcdoc');
      $('#smtpwp-v-body').removeAttr('hidden');
    }
  });
  if ($('#smtpwp-log-wrap').length) {
    var initPage = 1;
    try {
      var u = new URL(window.location.href);
      initPage = Math.max(1, parseInt(u.searchParams.get('paged'), 10) || 1);
    } catch(e){}
    if (initPage > 1) { loadLog(initPage); }
    else {
      var total = parseInt($('#smtpwp-log-count').text(), 10) || 0;
      renderLogPages(1, Math.max(1, Math.ceil(total / 20)));
    }
  }
});
